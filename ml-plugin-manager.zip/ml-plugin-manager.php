<?php
/**
 * Plugin Name: ML Plugin Manager
 * Plugin URI: https://minutelaunch.com
 * Description: Manages your MinuteLaunch plugin collection - works automatically, no token needed
 * Version: 4.0.9
 * Author: MinuteLaunch
 * License: GPL v2 or later
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 * TABLE OF CONTENTS
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * 1. INITIALIZATION & SETUP
 *    - Plugin constants and security checks
 *    - Class initialization and WordPress hooks
 * 
 * 2. ADMIN INTERFACE
 *    - Admin menu registration
 *    - Admin page rendering
 *    - Admin styles and scripts
 * 
 * 3. AUTHENTICATION
 *    - Token-based authentication (GitHub tokens.json)
 *    - Token validation and management
 * 
 * 4. PLUGIN INVENTORY MANAGEMENT
 *    - Fetch plugin inventory from GitHub
 *    - Demo inventory fallback
 *    - Cache management
 * 
 * 5. VIRTUAL PLUGIN LOADING (CORE FUNCTIONALITY)
 *    - Safety Valve #1: URL Parameter Override (?ml_safe_mode=1)
 *    - Safety Valve #2: Emergency Disable File (ml-emergency-disable.txt)
 *    - Safety Valve #3: Auto-Disable on Repeated Failures
 *    - Plugin code fetching and execution
 *    - Error tracking and recovery
 * 
 * 6. PLUGIN ACTIVATION/DEACTIVATION
 *    - Toggle virtual plugins
 *    - Cache clearing on deactivation
 * 
 * 7. WORDPRESS INTEGRATION
 *    - Add virtual plugins to WordPress plugins list
 *    - Bypass WordPress validation for virtual plugins
 *    - Filter active plugins for loading
 * 
 * 8. UPDATE SYSTEM
 *    - Check for plugin updates
 *    - Auto-update scheduler
 *    - Update notifications
 * 
 * 9. DEMO PLUGINS
 *    - Demo calculator
 *    - Test plugin
 * 
 * 10. SAFETY VALVE HANDLERS (NEW IN v2.0.0)
 *     - Clear failed plugins
 *     - Handle clear failed link
 *     - Failed plugin tracking
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 * CHANGELOG
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * v2.1.0 (October 22, 2025) - CRITICAL: WordPress-Style Versioning
 * ───────────────────────────────────────────────────────────────────────────
 * 
 * THE PROBLEM WE SOLVED:
 * When plugin filenames included version numbers (e.g., ml-claude-mcp-7.2.4.php),
 * updating to a new version (7.2.5) would break all existing site connections
 * because sites would try to load the old filename that no longer exists.
 * 
 * THE SOLUTION:
 * Adopted WordPress-style versioning where:
 * - Filenames stay CONSISTENT (ml-claude-mcp.php - no version number)
 * - Version numbers live in file headers and inventory.json
 * - Cache keys use md5(slug) instead of slug+version
 * - Updates are now SEAMLESS - sites continue working during updates
 * 
 * CHANGES IN v2.1.0:
 * 1. ✅ Removed version numbers from ALL plugin filenames in inventory.json
 * 2. ✅ Updated cache key logic: 'ml_plugin_code_' . md5($plugin_slug)
 * 3. ✅ Simplified deactivation cache clearing (no version lookup needed)
 * 4. ✅ Simplified failed plugin cache clearing (no version lookup needed)
 * 5. ✅ Renamed all plugin files to remove version numbers
 * 
 * BENEFITS:
 * - Zero-downtime updates - sites continue working during version changes
 * - Automatic deployment - no manual intervention required
 * - Industry standard - follows WordPress best practices
 * - Graceful transitions - cache system ensures smooth updates
 * - Developer-friendly - simple, predictable deployment process
 * 
 * HOW AUTO-UPDATES WORK NOW:
 * 1. Developer updates plugin file header: Version: 7.2.4 → 7.2.5
 * 2. Developer updates inventory.json version field (file stays same)
 * 3. ML Plugin Manager detects update via version_compare()
 * 4. Cache is cleared for updated plugins
 * 5. Next load fetches fresh code from GitHub
 * 6. NO DISCONNECTION - same filename means seamless transition!
 * 
 * DEPLOYMENT WORKFLOW:
 * - Edit plugin file: Change version in header
 * - Edit inventory.json: Update version field only (NOT filename)
 * - Push to GitHub: Both files
 * - Sites auto-update within 24 hours (or manual "Check for Updates")
 * 
 * BACKWARD COMPATIBILITY:
 * - Fully compatible with v2.0.0
 * - No database migrations required
 * - All existing functionality preserved
 * - Only cache key format changed (transparent to users)
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 * CHANGELOG - v2.0.0 (October 20, 2024)
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * BASED ON: v1.0.1 (WORKING VERSION FROM PRODUCTION)
 * 
 * WHY THIS VERSION EXISTS:
 * - v1.0.1 was the last known working version on production sites
 * - Versions 1.1.x - 1.3.0 had issues and were not deployed
 * - v2.0.0 starts fresh from v1.0.1 with ONLY safety features added
 * - This ensures we keep all working functionality intact
 * 
 * NEW FEATURES (Safety Valves):
 * 
 * 1. URL Parameter Override (?ml_safe_mode=1)
 *    - Add to any admin URL to disable all virtual plugins instantly
 *    - Shows yellow warning banner with exit link
 *    - Perfect for emergency lockout situations
 * 
 * 2. Emergency Disable File (ml-emergency-disable.txt)
 *    - Create file via FTP/SSH to disable all virtual plugins
 *    - Works even with white screen of death
 *    - Shows red error banner with instructions
 *    - Ultimate failsafe when WordPress won't load
 * 
 * 3. Auto-Disable on Repeated Failures
 *    - Tracks plugin execution errors automatically
 *    - Auto-disables plugins after 3 failures within 1 hour
 *    - Shows admin warnings with error details
 *    - Individual "Clear & Retry" links for each failed plugin
 *    - "Clear All Failed Plugins" button for bulk recovery
 * 
 * TECHNICAL IMPLEMENTATION:
 * - Error handling with try-catch and Throwable support
 * - Custom error handler converts warnings to exceptions
 * - Failure tracking stored in ml_failed_plugins option
 * - Safe mode checked at plugins_loaded priority 1 (earliest possible)
 * - Emergency file check before any plugin loading
 * - Zero performance impact on normal operation (< 1ms overhead)
 * 
 * NEW AJAX ENDPOINTS:
 * - ml_clear_failed_plugins: Clear all failed plugin tracking
 * - handle_clear_failed_link: Clear specific plugin failures via URL
 * 
 * ADMIN INTERFACE ADDITIONS:
 * - "Clear Failed Plugins" button in toolbar
 * - Failed plugins warning section with error details
 * - Individual "Clear & Retry" links
 * - "Enter Safe Mode" quick link
 * - Safe mode warning banner
 * - Emergency mode error banner
 * 
 * BACKWARD COMPATIBILITY:
 * - Fully compatible with v1.0.1
 * - No database migrations required
 * - No breaking changes to existing functionality
 * - All v1.0.1 features preserved exactly as they were
 * 
 * WHAT WAS NOT CHANGED FROM v1.0.1:
 * - Authentication system (unchanged)
 * - Plugin inventory fetching (unchanged)
 * - Admin interface layout (unchanged)
 * - Plugin activation/deactivation (unchanged)
 * - Update checking system (unchanged)
 * - Demo plugins (unchanged)
 * 
 * WHAT WAS ADDED:
 * - Safety valve checks in load_virtual_plugins_early()
 * - Error tracking and auto-disable logic
 * - Failed plugin management functions
 * - Admin notices for failed plugins
 * - Recovery UI elements
 * - Table of Contents and section markers (this documentation)
 * 
 * EMERGENCY RECOVERY:
 * - Safe Mode URL: https://yoursite.com/wp-admin/?ml_safe_mode=1
 * - Emergency File: wp-content/plugins/ml-plugin-manager/ml-emergency-disable.txt
 * - Auto-Disable: Check MinuteLaunch admin for warnings after 3 failures
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: INITIALIZATION & SETUP
// ═══════════════════════════════════════════════════════════════════════════

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin version
define('MINUTELAUNCH_VERSION', '4.0.9');

// ═══════════════════════════════════════════════════════════════════════════
// GLOBAL HELPER FUNCTION - ml_get_api_key()
// ═══════════════════════════════════════════════════════════════════════════

if (!function_exists('ml_get_api_key')) {
    /**
     * Get API key with priority: Client Override > Central Key > Legacy Setting
     * 
     * @param string $provider Provider key (openrouter, serpapi, noun_project, google_ai_studio, kie_ai)
     * @param string $legacy_option Optional legacy option name for backward compatibility
     * @param string $field Optional field name for providers with multiple keys (e.g., 'api_secret' for Noun Project)
     * @return string API key or empty string
     */
    function ml_get_api_key($provider, $legacy_option = '', $field = 'key') {
        // DEBUG: Log what's being requested
        error_log("ml_get_api_key() called for provider: '$provider', field: '$field'");
        
        // 1. Check for client override first
        $overrides = get_option('ml_api_key_overrides', array());
        
        // DEBUG: Log all overrides
        if (!empty($overrides)) {
            error_log("ml_get_api_key() - Overrides available: " . implode(', ', array_keys($overrides)));
        }
        
        if (isset($overrides[$provider]) && !empty($overrides[$provider])) {
            // Handle dual-key overrides (Noun Project)
            if (is_array($overrides[$provider])) {
                if (isset($overrides[$provider][$field]) && !empty($overrides[$provider][$field])) {
                    $key = $overrides[$provider][$field];
                    error_log("ml_get_api_key() - Returning override (dual-key) for '$provider': " . substr($key, 0, 20) . "...");
                    return $key;
                }
                // If no specific field requested, return the array
            return $overrides[$provider];
            }
            // Single key override
            $key = $overrides[$provider];
            error_log("ml_get_api_key() - Returning override for '$provider': " . substr($key, 0, 20) . "...");
            return $key;
        }
        
        // 2. Check central keys from GitHub
        $central_keys = get_option('ml_central_api_keys', array());
        if (!empty($central_keys['keys'][$provider])) {
            $key_data = $central_keys['keys'][$provider];
            
            // Handle providers with multiple fields (like Noun Project)
            if (isset($key_data[$field]) && !empty($key_data[$field])) {
                return $key_data[$field];
            }
            
            // Default to 'key' field
            if (isset($key_data['key']) && !empty($key_data['key'])) {
                return $key_data['key'];
            }
        }
        
        // 3. Fall back to legacy option for backward compatibility
        if (!empty($legacy_option)) {
            $legacy_key = get_option($legacy_option, '');
            if (!empty($legacy_key)) {
                return $legacy_key;
            }
        }
        
        return '';
    }
}

class MinuteLaunchManager {
    // ═══════════════════════════════════════════════════════════════════════════
    // v4.0.0 REVOLUTIONARY CHANGE: Zero-Token Architecture
    // ═══════════════════════════════════════════════════════════════════════════
    // 
    // OLD SYSTEM (v3.x):
    // - Users had to enter ML tokens
    // - Token validation required
    // - Friction for users
    // 
    // NEW SYSTEM (v4.0.0):
    // - Plugin works IMMEDIATELY on install (no token!)
    // - Automatically phones home and registers
    // - You control access remotely via dashboard
    // - Default: ACTIVE (fail-safe)
    // - Can auto-disable unauthorized sites
    // 
    // USER EXPERIENCE:
    // 1. Install plugin → Works immediately
    // 2. All plugins available instantly
    // 3. Zero configuration needed
    // 
    // ADMIN EXPERIENCE:
    // 1. Dashboard shows all sites automatically
    // 2. Click Enable/Disable to control access
    // 3. Optional: Auto-disable non-customers
    // 
    // ═══════════════════════════════════════════════════════════════════════════
    
    // v4.0.5: Direct GitHub access with hardcoded token (no relay dependency)
    private $github_token = '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';
    private $github_repo = 'wplaunchify/ml-plugin-manager';
    private $status_file_url = 'https://raw.githubusercontent.com/wplaunchify/ml-plugin-manager-relay/main/approved-sites.json';
    private $site_active = true; // Default: ACTIVE (fail-safe)
    private $authenticated = true; // v4.0.5: Always authenticated (no token needed)
    private $virtual_plugins = [];
    private $plugin_url;
    private $plugin_path;
    
    public function __construct() {
        $this->plugin_url = plugin_dir_url(__FILE__);
        $this->plugin_path = plugin_dir_path(__FILE__);
        
        // ═══════════════════════════════════════════════════════════════════════════
        // CRITICAL: Check safety valves FIRST before doing anything else
        // ═══════════════════════════════════════════════════════════════════════════
        $safe_mode_active = $this->check_safety_valves();
        
        // ═══════════════════════════════════════════════════════════════════════════
        // v4.0.0: Auto-Registration + Status Check
        // 1. Register this site automatically (phone home)
        // 2. Check if site is active via daily status check
        // 3. Default: ACTIVE (fail-safe if GitHub unreachable)
        // ═══════════════════════════════════════════════════════════════════════════
        $this->register_site(); // NEW: Auto-register on first load
        $this->site_active = $this->check_site_status();
        
        // v4.0.0: Always load plugins (no token needed!)
        // If site is active, load virtual plugins
        if ($this->site_active) {
            $this->load_virtual_plugins();
        }
        
        // WordPress hooks
        add_action('admin_menu', [$this, 'add_admin_page']);
        add_action('admin_menu', [$this, 'add_virtual_plugin_menus'], 20); // Later priority
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('admin_head', [$this, 'output_global_admin_css'], 1);
        add_action('admin_notices', [$this, 'hide_plugin_notices'], 999);
        add_action('wp_ajax_ml_toggle_plugin', [$this, 'toggle_virtual_plugin']);
        add_action('wp_ajax_ml_execute_plugin', [$this, 'execute_virtual_plugin']);
        
        // API Key Manager AJAX handlers
        add_action('wp_ajax_ml_sync_api_keys', [$this, 'ajax_sync_api_keys']);
        add_action('wp_ajax_ml_save_api_key_override', [$this, 'ajax_save_api_key_override']);
        add_action('wp_ajax_ml_save_api_key_override_dual', [$this, 'ajax_save_api_key_override_dual']);
        add_action('wp_ajax_ml_remove_api_key_override', [$this, 'ajax_remove_api_key_override']);
        
        // Auto-sync API keys on init (if cache expired)
        add_action('init', [$this, 'maybe_sync_api_keys']);
        
        add_action('wp_ajax_ml_check_updates', [$this, 'check_for_updates']);
        add_action('wp_ajax_ml_check_for_updates', [$this, 'ajax_check_for_updates']);
        add_action('wp_ajax_ml_install_plugin_manager_update', [$this, 'ajax_install_plugin_manager_update']);
        add_action('wp_ajax_ml_dismiss_announcement', [$this, 'ajax_dismiss_announcement']);
        // v4.0.0: Removed token login/logout (no longer needed)
        add_action('wp_ajax_ml_refresh_inventory', [$this, 'refresh_inventory_cache']);
        add_action('wp_ajax_ml_clear_failed_plugins', [$this, 'clear_failed_plugins']);
        add_action('wp_ajax_ml_clear_all_caches', [$this, 'ajax_clear_all_caches']);
        add_action('wp_ajax_ml_export_standalone', [$this, 'export_standalone_plugin']);
        add_action('wp_ajax_ml_install_physical_plugin', [$this, 'ajax_install_physical_plugin']);
        
        // Handle clear failed plugin link
        add_action('admin_init', [$this, 'handle_clear_failed_link']);
        // Add virtual plugins to WordPress plugins list
        add_filter('all_plugins', [$this, 'add_virtual_plugins_to_list']);
        add_filter('plugin_action_links', [$this, 'modify_virtual_plugin_actions'], 10, 2);
        add_filter('option_active_plugins', [$this, 'add_virtual_to_active_list']);
        // Prevent WordPress from validating virtual plugin files
        add_filter('validate_plugin', [$this, 'bypass_virtual_plugin_validation'], 10, 2);
        add_filter('validate_file', [$this, 'bypass_virtual_file_validation'], 10, 2);
        
        // Load virtual plugins after WordPress core but before theme
        // BUT ONLY if safe mode is NOT active
        if (!$safe_mode_active) {
            add_action('plugins_loaded', [$this, 'load_virtual_plugins_early'], 1);
        }
        // Remove virtual plugins from the active_plugins option that WP tries to load
        add_filter('pre_option_active_plugins', [$this, 'filter_active_plugins_for_loading'], 1);
        
        // AUTO-UPDATE SYSTEM: ENABLED with fixed temp filenames (no more random suffixes!)
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_plugin_updates']);
        add_filter('plugins_api', [$this, 'plugin_info'], 10, 3);
        add_filter('upgrader_pre_download', [$this, 'download_package_with_auth'], 10, 3);
        // Auto-update scheduler
        if (!wp_next_scheduled('ml_auto_update_check')) {
            wp_schedule_event(time(), 'daily', 'ml_auto_update_check');
        }
        add_action('ml_auto_update_check', [$this, 'auto_update_plugins']);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 1.5: SAFETY VALVE SYSTEM (CRITICAL - RUNS BEFORE EVERYTHING)
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Check all safety valves BEFORE loading any virtual plugins
     * Returns true if safe mode is active, false otherwise
     */
    private function check_safety_valves() {
        // SAFETY VALVE #1: URL Parameter Override (?ml_safe_mode=1)
        if (isset($_GET['ml_safe_mode']) && $_GET['ml_safe_mode'] == '1') {
            error_log('MinuteLaunch: SAFE MODE ENABLED via URL parameter - all virtual plugins disabled');
            
            // Clear ALL plugin caches when entering safe mode
            $this->clear_all_plugin_caches();
            
            add_action('admin_notices', function() {
                echo '<div class="notice notice-warning" style="border-left: 4px solid #ffb900; padding: 12px;">';
                echo '<p style="margin: 0; font-size: 14px;"><strong>⚠️ MinuteLaunch Safe Mode Active</strong></p>';
                echo '<p style="margin: 8px 0 0 0;">All virtual plugins are disabled. All caches have been cleared.</p>';
                echo '<p style="margin: 8px 0 0 0;">';
                echo '<a href="' . admin_url('admin.php?page=minutelaunch-plugins') . '" class="button">Manage Plugins</a> ';
                echo '<a href="' . remove_query_arg('ml_safe_mode') . '" class="button button-primary">Exit Safe Mode</a>';
                echo '</p>';
                echo '</div>';
            });
            
            return true;
        }
        
        // SAFETY VALVE #2: Emergency Disable File (ml-emergency-disable.txt)
        $emergency_file = $this->plugin_path . 'ml-emergency-disable.txt';
        if (file_exists($emergency_file)) {
            error_log('MinuteLaunch: EMERGENCY DISABLE FILE DETECTED - all virtual plugins disabled');
            
            // Clear ALL plugin caches when emergency file is detected
            $this->clear_all_plugin_caches();
            
            add_action('admin_notices', function() use ($emergency_file) {
                echo '<div class="notice notice-error" style="border-left: 4px solid #dc3232; padding: 12px;">';
                echo '<p style="margin: 0; font-size: 14px;"><strong>🚨 MinuteLaunch Emergency Mode</strong></p>';
                echo '<p style="margin: 8px 0 0 0;">All virtual plugins are disabled due to emergency file. All caches have been cleared.</p>';
                echo '<p style="margin: 8px 0 0 0;"><strong>To re-enable:</strong> Delete <code>ml-emergency-disable.txt</code> from:<br><code>' . esc_html($emergency_file) . '</code></p>';
                echo '<p style="margin: 8px 0 0 0;">';
                echo '<a href="' . admin_url('admin.php?page=minutelaunch-plugins') . '" class="button">Manage Plugins</a>';
                echo '</p>';
                echo '</div>';
            });
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Clear all plugin code caches and opcache
     * Called when entering safe mode or emergency mode
     */
    private function clear_all_plugin_caches() {
        global $wpdb;
        
        // Clear all ml_plugin_code_* transients
        $deleted = $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_ml_plugin_code_%' 
             OR option_name LIKE '_transient_timeout_ml_plugin_code_%'"
        );
        
        // Clear opcache if available
        if (function_exists('opcache_reset')) {
            @opcache_reset(); // Suppress notices
            error_log("MinuteLaunch: Cleared opcache");
        }
        
        error_log("MinuteLaunch: Cleared {$deleted} plugin code caches");
        
        return $deleted; // Return count for feedback
    }
    
    /**
     * AJAX handler for manual cache clearing
     */
    public function ajax_clear_all_caches() {
        // Start output buffering to catch any stray output
        ob_start();
        
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            ob_end_clean();
            wp_send_json_error('Insufficient permissions');
        }
        
        $deleted = $this->clear_all_plugin_caches();
        
        // Clean any output that might have been generated
        ob_end_clean();
        
        wp_send_json_success([
            'message' => 'All caches cleared successfully',
            'deleted' => $deleted
        ]);
    }
    
    /**
     * AJAX: Check for plugin manager updates
     */
    public function ajax_check_for_updates() {
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }
        
        // SAFE MANUAL UPDATE: Check GitHub directly (no WordPress hooks that trigger LearnDash)
        $response = wp_remote_get('https://api.github.com/repos/wplaunchify/ml-plugin-manager/releases/latest', [
            'headers' => [
                'Authorization' => 'token ' . $this->github_token,
                'Accept' => 'application/vnd.github.v3+json',
                'User-Agent' => 'MinuteLaunch-Plugin-Manager'
            ],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            wp_send_json_error(['message' => 'Failed to check for updates: ' . $response->get_error_message()]);
        }
        
        $release = json_decode(wp_remote_retrieve_body($response), true);
        if (!$release || !isset($release['tag_name'])) {
            wp_send_json_error(['message' => 'Invalid response from GitHub']);
        }
        
        $latest_version = ltrim($release['tag_name'], 'v');
        $current_version = MINUTELAUNCH_VERSION;
        
        if (version_compare($latest_version, $current_version, '>')) {
            // Find the ml-plugin-manager.zip asset
            $download_url = null;
            if (isset($release['assets'])) {
                foreach ($release['assets'] as $asset) {
                    if ($asset['name'] === 'ml-plugin-manager.zip') {
                        $download_url = $asset['url']; // Use API URL for private repo
                        break;
                    }
                }
            }
            
            wp_send_json_success([
                'update_available' => true,
                'version' => $latest_version,
                'current_version' => $current_version,
                'download_url' => $download_url,
                'release_notes' => $release['body'] ?? ''
            ]);
        } else {
            wp_send_json_success([
                'update_available' => false,
                'current_version' => $current_version
            ]);
        }
    }
    
    /**
     * AJAX: Install plugin manager update
     */
    public function ajax_install_plugin_manager_update() {
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }
        
        $download_url = sanitize_text_field($_POST['download_url'] ?? '');
        if (empty($download_url)) {
            wp_send_json_error(['message' => 'No download URL provided']);
        }
        
        // Download the ZIP from GitHub using API URL with token auth
        $response = wp_remote_get($download_url, [
            'headers' => [
                'Authorization' => 'token ' . $this->github_token,
                'Accept' => 'application/octet-stream',
                'User-Agent' => 'MinuteLaunch-Plugin-Manager'
            ],
            'timeout' => 60
        ]);
        
        if (is_wp_error($response)) {
            wp_send_json_error(['message' => 'Failed to download update: ' . $response->get_error_message()]);
        }
        
        $zip_data = wp_remote_retrieve_body($response);
        if (empty($zip_data)) {
            wp_send_json_error(['message' => 'Downloaded file is empty']);
        }
        
        // MANUAL REPLACEMENT: Extract and replace the current file
        require_once ABSPATH . 'wp-admin/includes/file.php';
        WP_Filesystem();
        global $wp_filesystem;
        
        // Save ZIP to temp location with FIXED filename (prevents random suffixes)
        $temp_file = sys_get_temp_dir() . '/ml-plugin-manager-update.zip';
        file_put_contents($temp_file, $zip_data);
        
        // Extract ZIP to temp directory
        $temp_dir = get_temp_dir() . 'ml-update-' . time();
        $unzip_result = unzip_file($temp_file, $temp_dir);
        
        if (is_wp_error($unzip_result)) {
            @unlink($temp_file);
            wp_send_json_error(['message' => 'Failed to extract update: ' . $unzip_result->get_error_message()]);
        }
        
        // Find the plugin file in extracted content
        $extracted_file = $temp_dir . '/ml-plugin-manager.php';
        if (!file_exists($extracted_file)) {
            @unlink($temp_file);
            $wp_filesystem->rmdir($temp_dir, true);
            wp_send_json_error(['message' => 'Plugin file not found in update package']);
        }
        
        // Get current plugin file path
        $current_file = __FILE__;
        
        // Create backup
        $backup_file = $current_file . '.backup';
        copy($current_file, $backup_file);
        
        // Replace the current file with the new one
        if (!copy($extracted_file, $current_file)) {
            // Restore backup on failure
            copy($backup_file, $current_file);
            @unlink($temp_file);
            @unlink($backup_file);
            $wp_filesystem->rmdir($temp_dir, true);
            wp_send_json_error(['message' => 'Failed to replace plugin file']);
        }
        
        // Clean up
        @unlink($temp_file);
        @unlink($backup_file);
        $wp_filesystem->rmdir($temp_dir, true);
        
        wp_send_json_success(['message' => 'Plugin Manager updated successfully!']);
    }
    
    /**
     * AJAX: Dismiss announcement
     */
    public function ajax_dismiss_announcement() {
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }
        
        $announcement_id = sanitize_text_field($_POST['announcement_id'] ?? '');
        if (empty($announcement_id)) {
            wp_send_json_error(['message' => 'Invalid announcement ID']);
        }
        
        $dismissed = get_option('ml_dismissed_announcements', []);
        if (!in_array($announcement_id, $dismissed)) {
            $dismissed[] = $announcement_id;
            update_option('ml_dismissed_announcements', $dismissed);
        }
        
        // Clear announcements cache
        delete_transient('ml_announcements');
        
        wp_send_json_success(['message' => 'Announcement dismissed']);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 2: ADMIN INTERFACE
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function add_admin_page() {
        $updates_available = get_option('ml_updates_available', 0);
        $menu_title = 'MinuteLaunch';
        if ($updates_available > 0) {
            $menu_title .= ' <span class="update-plugins count-' . $updates_available . '"><span class="update-count">' . $updates_available . '</span></span>';
        }
        add_menu_page(
            'MinuteLaunch Plugins',
            $menu_title,
            'manage_options',
            'minutelaunch-plugins',
            [$this, 'render_admin_page'],
            'https://raw.githubusercontent.com/wplaunchify/ml-assets/main/min-launch-no-grey-no-shadow.png',
            30
        );
    }
    
    public function add_virtual_plugin_menus() {
        $active_plugins = get_option('ml_active_plugins', []);
        // Only handle demo plugins here - real plugins are loaded in load_virtual_plugins_early()
        foreach ($active_plugins as $plugin_slug) {
            if ($plugin_slug === 'demo-calculator') {
                add_menu_page(
                    'ML Calculator',
                    '⚡ ML Calculator',
                    'manage_options',
                    'demo-calculator',
                    [$this, 'render_calculator_page'],
                    'dashicons-calculator',
                    25
                );
            } elseif ($plugin_slug === 'test-plugin') {
                add_menu_page(
                    'ML Test Plugin',
                    '⚡ ML Test Plugin',
                    'manage_options',
                    'test-plugin-demo',
                    [$this, 'render_test_plugin_page'],
                    'dashicons-admin-plugins',
                    26
                );
            }
            // Real plugins are already loaded via load_virtual_plugins_early()
            // They register their own menus when executed
        }
    }
    

    public function hide_plugin_notices() {
        ?>
        <script>
        jQuery(document).ready(function($) {
            // Hide error notices about minutelaunch-virtual plugins
            $('.notice-error, .error').each(function() {
                var text = $(this).text();
                if (text.indexOf('minutelaunch-virtual') > -1 || 
                    text.indexOf('plugin file does not exist') > -1) {
                    $(this).remove();
                }
            });
        });
        </script>
        <?php
    }


    public function output_global_admin_css() {
        ?>
        <style>
        /* Hide the img tag and use ::before instead */
        #adminmenu li#toplevel_page_minutelaunch-plugins .wp-menu-image img {
            display: none !important;
        }
        /* Use ::before for the icon on ALL states */
        #adminmenu li#toplevel_page_minutelaunch-plugins .wp-menu-image::before,
        #adminmenu li.wp-not-current-submenu#toplevel_page_minutelaunch-plugins .wp-menu-image::before,
        #adminmenu li.current#toplevel_page_minutelaunch-plugins .wp-menu-image::before {
            content: '' !important;
            background-image: url(https://raw.githubusercontent.com/wplaunchify/ml-assets/main/min-launch-no-grey-no-shadow.png) !important;
            background-size: 20px 20px !important;
            background-repeat: no-repeat !important;
            background-position: center center !important;
            width: 20px !important;
            height: 20px !important;
            display: block !important;
            opacity: 1;
            padding: 7px 7px;
        }
        #adminmenu li#toplevel_page_minutelaunch-plugins:hover .wp-menu-image::before,
        #adminmenu li.current#toplevel_page_minutelaunch-plugins .wp-menu-image::before {
            opacity: 1 !important;
        }
        </style>
        <?php
    }

    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_minutelaunch-plugins') {
            return;
        }
        // Embed CSS and JS inline - single file plugin!
        add_action('admin_head', [$this, 'output_admin_styles']);
        add_action('admin_footer', [$this, 'output_admin_scripts']);
    }
    
    public function output_admin_styles() {
        ?>
        <style>

        /* MinuteLaunch Plugin Manager Admin Styles */
        
        /* Spinning icon animation */
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .spin-icon {
            display: inline-block;
            animation: spin 1s linear infinite;
        }
        
        .ml-license-section {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .ml-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .ml-stat-box {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 20px;
            text-align: center;
            flex: 1;
            min-width: 200px;
        }
        .ml-stat-box h3 {
            font-size: 2em;
            margin: 0 0 10px 0;
            color: #0073aa;
        }
        .ml-stat-box p {
            margin: 0;
            color: #666;
        }
        .ml-actions {
            margin-bottom: 20px;
        }
        .ml-actions .button {
            margin-right: 10px;
        }
        .plugin-browser {
            margin-top: 20px;
        }
        .plugin-browser table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .plugin-browser th {
            text-align: left;
            padding: 12px;
            background: #f9f9f9;
            border-bottom: 1px solid #ddd;
            font-weight: 600;
        }
        .plugin-browser td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }
        .plugin-browser tbody tr {
            background: #fff;
        }
        .plugin-browser tbody tr:nth-child(odd) {
            background: #f9f9f9;
        }
        .plugin-browser tbody tr:hover {
            background: #e8f5fa;
        }
        .plugin-name {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
            font-size: 14px;
        }
        .plugin-icon {
            font-size: 20px;
        }
        .plugin-status {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 8px;
        }
        .plugin-status.active {
            background: #46b450;
            color: white;
        }
        .plugin-status.inactive {
            background: #ccd0d4;
            color: #666;
        }
        .plugin-description {
            color: #666;
            font-size: 13px;
            margin-top: 4px;
        }
        .plugin-meta {
            color: #999;
            font-size: 12px;
            margin-top: 4px;
        }
        .ml-activate, .ml-deactivate {
            min-width: 100px;
        }
        #ml-update-results {
            margin: 20px 0;
            padding: 15px;
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            display: none;
        }
        #ml-update-results.show {
            display: block;
        }
        .ml-update-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .ml-update-item:last-child {
            border-bottom: none;
        }
        .ml-loading {
            opacity: 0.6;
            pointer-events: none;
        }
        .ml-loading::after {
            content: " (Loading...)";
            color: #666;
        }
        /* Custom MinuteLaunch Icon */
        #adminmenu #toplevel_page_minutelaunch-plugins .wp-menu-image img {
            display: none;
        }
        #adminmenu #toplevel_page_minutelaunch-plugins .wp-menu-image:before {
            content: '';
            background-image: url('https://raw.githubusercontent.com/wplaunchify/ml-assets/main/min-launch-no-grey-no-shadow.png');
            background-size: 20px 20px;
            background-repeat: no-repeat;
            background-position: center center;
            width: 20px;
            height: 20px;
            display: block;
        }
        /* v3.0.1 Clean Interface */
        .ml-wrap { background: #fff; padding: 0; margin: 20px 20px 20px 0; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .ml-notification { margin: 15px; padding: 12px 15px; border-radius: 4px; animation: slideIn 0.3s; }
        .ml-notification.show { display: block !important; }
        .ml-notification.success { background: #d4edda; border-left: 4px solid #28a745; color: #155724; }
        .ml-notification.error { background: #f8d7da; border-left: 4px solid #dc3545; color: #721c24; }
        @keyframes slideIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .ml-header { background: #ffffff; color: #333; padding: 25px 30px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e0e0e0; }
        .ml-header-left { display: flex; align-items: center; gap: 15px; }
        .ml-header-logo { width: 48px; height: 48px; }
        .ml-header-text { display: flex; flex-direction: column; }
        .ml-header h1 { margin: 0; font-size: 24px; font-weight: 600; color: #333; }
        .ml-tagline { margin: 5px 0 0 0; opacity: 0.7; font-size: 14px; color: #666; }
        .ml-login-form-inline { display: flex; gap: 10px; }
        .ml-login-form-inline input { padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; background: #fff; color: #333; }
        .ml-login-form-inline input::placeholder { color: #999; }
        .ml-login-form-inline button { padding: 8px 20px; background: #E55B10; color: white; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; transition: background 0.3s; }
        .ml-login-form-inline button:hover { background: #CC4E0B; }
        .ml-user-info { display: flex; gap: 15px; align-items: center; }
        .ml-user-email { color: #333; padding: 6px 12px; background: #f5f5f5; border-radius: 4px; border: 1px solid #ddd; }
        .ml-content { padding: 30px; }
        .ml-welcome-box { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 40px; text-align: center; max-width: 600px; margin: 0 auto; }
        .ml-welcome-box h2 { margin: 0 0 15px 0; }
        .ml-features { list-style: none; padding: 0; text-align: left; }
        .ml-features li { padding: 10px 0; }
        .ml-features li:before { content: "✓ "; color: #28a745; font-weight: bold; margin-right: 8px; }
        .ml-toolbar { display: flex; gap: 15px; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #dee2e6; }
        .ml-toolbar-info { color: #666; font-size: 13px; }
        .ml-empty-state { text-align: center; padding: 60px 20px; color: #666; background: #f8f9fa; border-radius: 8px; }
        /* MinuteLaunch Orange Buttons */
        .button-primary, #ml-refresh-inventory, .ml-activate { background: #E55B10 !important; border-color: #E55B10 !important; color: white !important; }
        .button-primary:hover, #ml-refresh-inventory:hover, .ml-activate:hover { background: #CC4E0B !important; border-color: #CC4E0B !important; }
        /* Sortable Table Headers */
        th[data-sort] { user-select: none; position: relative; padding-right: 20px; }
        th[data-sort]:hover { background: #f5f5f5; }
        .sort-indicator { position: absolute; right: 5px; opacity: 0.3; }
        .sort-indicator:after { content: "▼"; font-size: 10px; }
        th[data-sort].sorted-asc .sort-indicator { opacity: 1; }
        th[data-sort].sorted-asc .sort-indicator:after { content: "▲"; }
        th[data-sort].sorted-desc .sort-indicator { opacity: 1; }
        th[data-sort].sorted-desc .sort-indicator:after { content: "▼"; }
        
        /* API Key Manager Styles */
        .ml-api-keys-table {
            border: 1px solid #ddd;
        }
        .ml-api-keys-table .button {
            background: #fff;
            border: 1px solid #7e8993;
            color: #32373c;
            text-decoration: none;
            font-size: 13px;
            line-height: 2.15384615;
            min-height: 30px;
            padding: 0 10px;
            cursor: pointer;
            border-radius: 3px;
            white-space: nowrap;
        }
        .ml-api-keys-table .button:hover {
            background: #f6f7f7;
            border-color: #7e8993;
            color: #32373c;
        }
        .ml-api-keys-table .button-primary {
            background: #2271b1;
            border-color: #2271b1;
            color: #fff;
        }
        .ml-api-keys-table .button-primary:hover {
            background: #135e96;
            border-color: #135e96;
            color: #fff;
        }
        .ml-btn-fixed {
            width: 80px;
            text-align: center;
            display: inline-block;
        }
        /* Grey-scale buttons */
        .ml-btn-active {
            background: #f8f9fa !important;
            border-color: #ced4da !important;
            color: #495057 !important;
        }
        .ml-btn-active:hover {
            background: #e9ecef !important;
            border-color: #adb5bd !important;
        }
        .ml-btn-override {
            background: #ff6b35 !important;
            border-color: #ff6b35 !important;
            color: #fff !important;
        }
        .ml-btn-override:hover {
            background: #e55a2b !important;
            border-color: #e55a2b !important;
        }
        .ml-btn-add {
            background: #f8f9fa !important;
            border-color: #ced4da !important;
            color: #495057 !important;
        }
        .ml-btn-add:hover {
            background: #e9ecef !important;
            border-color: #adb5bd !important;
        }
        .ml-btn-get {
            background: #fff !important;
            border-color: #dee2e6 !important;
            color: #6c757d !important;
        }
        .ml-btn-get:hover {
            background: #f8f9fa !important;
            border-color: #ced4da !important;
        }
        </style>
        <?php
    }
    
    public function output_admin_scripts() {
        ?>
        <script>
        jQuery(document).ready(function($) {
            var mlAjax = {
                ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
                nonce: '<?php echo wp_create_nonce('ml_nonce'); ?>',
                redirect_url: '<?php echo admin_url('admin.php?page=minutelaunch-plugins'); ?>'
            };
                // Inline notification function
            function showNotification(message, type) {
                const $notification = $('#ml-notification');
                $notification.removeClass('success error info').addClass(type + ' show').text(message);
                setTimeout(function() {
                    $notification.removeClass('show');
                }, 4000);
            }
                // WPLaunchify Login
            $('#ml-login-form').on('submit', function(e) {
                e.preventDefault();
                const token = $('#ml-token').val().trim();
                if (!token) {
                    showNotification('Please enter your MinuteLaunch token', 'error');
                    return;
                }
                        const $form = $(this);
                const $button = $form.find('button[type="submit"]');
                const originalText = $button.text();
                $button.text('Validating...').prop('disabled', true);
                        $.post(mlAjax.ajaxurl, {
                    action: 'ml_wplaunchify_login',
                    token: token,
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        const customerName = response.data.customer || 'Customer';
                        showNotification('Token validated! Welcome ' + customerName + '!', 'success');
                        setTimeout(function() {
                            window.location.href = mlAjax.redirect_url;
                        }, 500);
                    } else {
                        showNotification('Token validation failed: ' + (response.data || 'Invalid or inactive token'), 'error');
                    }
                })
                .fail(function() {
                    showNotification('Token validation failed. Please check your token and try again.', 'error');
                })
                .always(function() {
                    $button.text(originalText).prop('disabled', false);
                });
            });
                // WPLaunchify Logout
            // Check for Updates button
            $('#ml-check-updates-btn').on('click', function(e) {
                e.preventDefault();
                const $button = $(this);
                const originalHtml = $button.html();
                $button.html('<span class="dashicons dashicons-update spin-icon" style="margin-top: 3px;"></span> Checking...').prop('disabled', true);
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_check_for_updates',
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        if (response.data.update_available) {
                            // Show update available message and auto-install
                            showNotification('✓ Update available! Version ' + response.data.version + ' - Installing now...', 'success');
                            $button.html('<span class="dashicons dashicons-update spin-icon" style="margin-top: 3px;"></span> Installing...').prop('disabled', true);
                            
                            // Install the update
                            $.post(mlAjax.ajaxurl, {
                                action: 'ml_install_plugin_manager_update',
                                nonce: mlAjax.nonce,
                                download_url: response.data.download_url
                            })
                            .done(function(installResponse) {
                                if (installResponse.success) {
                                    showNotification('✓ Update installed successfully! Reloading...', 'success');
                                    setTimeout(function() {
                                        location.reload();
                                    }, 1500);
                                } else {
                                    showNotification('✗ Installation failed: ' + installResponse.data.message, 'error');
                                    $button.html(originalHtml).prop('disabled', false);
                                }
                            })
                            .fail(function() {
                                showNotification('✗ Installation failed. Please try again.', 'error');
                                $button.html(originalHtml).prop('disabled', false);
                            });
                        } else {
                            showNotification('✓ You are running the latest version (' + response.data.current_version + ')', 'success');
                            $button.html(originalHtml).prop('disabled', false);
                        }
                    } else {
                        showNotification('✗ ' + (response.data.message || 'Failed to check for updates'), 'error');
                        $button.html(originalHtml).prop('disabled', false);
                    }
                })
                .fail(function() {
                    showNotification('✗ Failed to check for updates. Please try again.', 'error');
                    $button.html(originalHtml).prop('disabled', false);
                });
            });
            
            $('#ml-logout-btn').on('click', function(e) {
                e.preventDefault();
                const $button = $(this);
                const originalText = $button.text();
                $button.text('Logging out...').prop('disabled', true);
                        $.post(mlAjax.ajaxurl, {
                    action: 'ml_wplaunchify_logout',
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    window.location.href = mlAjax.redirect_url;
                })
                .fail(function() {
                    showNotification('Logout failed. Please try again.', 'error');
                    $button.text(originalText).prop('disabled', false);
                });
            });
                // Plugin activation/deactivation
            $(document).on('click', '.ml-activate, .ml-deactivate', function(e) {
                e.preventDefault();
                        const $button = $(this);
                const pluginSlug = $button.data('plugin');
                const isActivating = $button.hasClass('ml-activate');
                const action = isActivating ? 'activate' : 'deactivate';
                const originalText = $button.text();
                        $button.text(isActivating ? 'Activating...' : 'Deactivating...').prop('disabled', true);
                        $.post(mlAjax.ajaxurl, {
                    action: 'ml_toggle_plugin',
                    plugin: pluginSlug,
                    toggle_action: action,
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        // For both activation and deactivation, refresh the entire admin page (not just iframe)
                        if (window.top !== window.self) {
                            window.top.location.reload();
                        } else {
                            location.reload();
                        }
                    } else {
                        showNotification('Failed to ' + action + ' plugin: ' + (response.data || 'Unknown error'), 'error');
                    }
                })
                .fail(function() {
                    showNotification('Failed to ' + action + ' plugin. Please try again.', 'error');
                })
                .always(function() {
                    $button.prop('disabled', false);
                });
            });
                // Clear all caches button
            $('#ml-clear-all-caches').on('click', function(e) {
                e.preventDefault();
                const $button = $(this);
                const originalText = $button.text();
                
                // No confirmation needed - just clear caches
                $button.text('Clearing...').prop('disabled', true);
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_clear_all_caches',
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        showNotification('All caches cleared successfully!', 'success');
                    } else {
                        showNotification('Failed to clear caches: ' + (response.data || 'Unknown error'), 'error');
                    }
                })
                .fail(function() {
                    showNotification('Network error while clearing caches', 'error');
                })
                .always(function() {
                    $button.text(originalText).prop('disabled', false);
                });
            });

            // Announcement action buttons
            $(document).on('click', '.ml-announcement-action', function(e) {
                e.preventDefault();
                const action = $(this).data('action');
                
                if (action === 'check_updates') {
                    $('#ml-check-updates-btn').trigger('click');
                }
            });
            
            // Dismiss announcement
            $(document).on('click', '.ml-dismiss-announcement', function(e) {
                e.preventDefault();
                const $notice = $(this).closest('.ml-announcement');
                const announcementId = $notice.data('announcement-id');
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_dismiss_announcement',
                    announcement_id: announcementId,
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        $notice.fadeOut();
                    }
                });
            });

            // Physical plugin activation
            $(document).on('click', '.ml-activate-physical', function(e) {
                e.preventDefault();
                const $button = $(this);
                const pluginFile = $button.data('plugin');
                const originalText = $button.text();
                
                $button.text('Activating...').prop('disabled', true);
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_toggle_plugin',
                    plugin: pluginFile,
                    toggle_action: 'activate',
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        showNotification('Plugin activated successfully!', 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showNotification('Activation failed: ' + (response.data || 'Unknown error'), 'error');
                        $button.text(originalText).prop('disabled', false);
                    }
                })
                .fail(function() {
                    showNotification('Network error during activation', 'error');
                    $button.text(originalText).prop('disabled', false);
                });
            });

            // Physical plugin installation
            $(document).on('click', '.ml-install-physical', function(e) {
                e.preventDefault();
                const $button = $(this);
                const slug = $button.data('slug');
                const repo = $button.data('repo');
                const zip = $button.data('zip');
                const originalText = $button.text();
                
                console.log('Install button clicked:', {slug, repo, zip, ajaxurl: mlAjax.ajaxurl});
                
                $button.text('Installing...').prop('disabled', true);
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_install_physical_plugin',
                    slug: slug,
                    repository: repo,
                    zip_file: zip,
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        showNotification(response.data.message || 'Plugin installed successfully!', 'success');
                        // Reload page to show new status
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showNotification('Installation failed: ' + (response.data || 'Unknown error'), 'error');
                        $button.text(originalText).prop('disabled', false);
                    }
                })
                .fail(function() {
                    showNotification('Network error during installation', 'error');
                    $button.text(originalText).prop('disabled', false);
                });
            });
            
            // Export Standalone Plugin
            $(document).on('click', '.ml-export-standalone', function(e) {
                e.preventDefault();
                const $button = $(this);
                const pluginSlug = $button.data('plugin');
                const pluginName = $button.data('name');
                const originalText = $button.text();
                
                showNotification('Exporting standalone version of "' + pluginName + '"...', 'info');
                $button.text('⏳ Exporting...').prop('disabled', true);
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_export_standalone',
                    plugin: pluginSlug,
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success && response.data.download_url) {
                        showNotification('Standalone plugin exported! Downloading...', 'success');
                        // Trigger download
                        window.location.href = response.data.download_url;
                    } else {
                        showNotification('Export failed: ' + (response.data || 'Unknown error'), 'error');
                    }
                })
                .fail(function() {
                    showNotification('Network error during export', 'error');
                })
                .always(function() {
                    $button.text(originalText).prop('disabled', false);
                });
            });
            
                // Check for updates
            $('#ml-check-updates').on('click', function(e) {
                e.preventDefault();
                        const $button = $(this);
                const originalText = $button.text();
                        $button.text('Checking...').prop('disabled', true);
                        $.post(mlAjax.ajaxurl, {
                    action: 'ml_check_updates',
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        const $results = $('#ml-update-results');
                                        if (response.data.updates && response.data.updates.length > 0) {
                            let html = '<h3>Updates Available:</h3>';
                            response.data.updates.forEach(function(update) {
                                html += '<div class="ml-update-item">';
                                html += '<strong>' + update.name + '</strong> ';
                                html += 'v' + update.current_version + ' → v' + update.new_version;
                                html += '</div>';
                            });
                            $results.html(html).addClass('show');
                                                setTimeout(function() {
                                if (window.top !== window.self) {
                                    window.top.location.reload();
                                } else {
                                    location.reload();
                                }
                            }, 2000);
                        } else {
                            showNotification(response.data.message, 'success');
                        }
                    } else {
                        showNotification('Failed to check for updates: ' + (response.data || 'Unknown error'), 'error');
                    }
                })
                .fail(function() {
                    showNotification('Failed to check for updates. Please try again.', 'error');
                })
                .always(function() {
                    $button.text(originalText).prop('disabled', false);
                });
            });
                // Refresh inventory
            $('#ml-refresh-inventory').on('click', function(e) {
                e.preventDefault();
                        const $button = $(this);
                const originalText = $button.text();
                        $button.text('Refreshing...').prop('disabled', true);
                        $.post(mlAjax.ajaxurl, {
                    action: 'ml_refresh_inventory',
                    nonce: mlAjax.nonce
                })
                .done(function(response) {
                    // Always refresh the page after clearing caches
                    setTimeout(function() {
                        if (window.top !== window.self) {
                            window.top.location.reload();
                        } else {
                            location.reload();
                        }
                    }, 500);
                })
                .fail(function() {
                    showNotification('Failed to refresh inventory. Please try again.', 'error');
                    $button.text(originalText).prop('disabled', false);
                });
            });
                function showMessage(message, type) {
                const $message = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
                $('.wrap h1').after($message);
                        setTimeout(function() {
                    $message.fadeOut(function() {
                        $(this).remove();
                    });
                }, 3000);
            }
                // Table Sorting Functionality
            let currentSort = { column: 'name', direction: 'asc' };
                // Sort table on page load by name (alphabetical)
            sortTable('name', 'asc');
                $('th[data-sort]').on('click', function() {
                const column = $(this).data('sort');
                const newDirection = (currentSort.column === column && currentSort.direction === 'asc') ? 'desc' : 'asc';
                sortTable(column, newDirection);
            });
                function sortTable(column, direction) {
                const $tbody = $('#ml-plugins-table tbody');
                const $rows = $tbody.find('tr').toArray();
                        // Sort rows
                $rows.sort(function(a, b) {
                    let aVal = $(a).data(column);
                    let bVal = $(b).data(column);
                                // Convert to strings for comparison
                    aVal = String(aVal).toLowerCase();
                    bVal = String(bVal).toLowerCase();
                                if (aVal < bVal) return direction === 'asc' ? -1 : 1;
                    if (aVal > bVal) return direction === 'asc' ? 1 : -1;
                    return 0;
                });
                        // Reorder rows
                $.each($rows, function(index, row) {
                    $tbody.append(row);
                });
                        // Update header indicators
                $('th[data-sort]').removeClass('sorted-asc sorted-desc');
                $('th[data-sort="' + column + '"]').addClass('sorted-' + direction);
                        currentSort = { column: column, direction: direction };
            }
            
            // ═══════════════════════════════════════════════════════════════════════════
            // API KEY MANAGER JAVASCRIPT
            // ═══════════════════════════════════════════════════════════════════════════
            
            // Notification helper for API keys
            function showApiNotification(message, type) {
                var $notification = $('#ml-api-notification');
                var colors = {
                    success: { bg: '#d4edda', border: '#28a745', text: '#155724' },
                    error: { bg: '#f8d7da', border: '#dc3545', text: '#721c24' },
                    info: { bg: '#d1ecf1', border: '#17a2b8', text: '#0c5460' }
                };
                var color = colors[type] || colors.info;
                
                $notification
                    .css({
                        'background': color.bg,
                        'border-left-color': color.border,
                        'color': color.text,
                        'display': 'block'
                    })
                    .html(message);
                
                if (type === 'success') {
                    setTimeout(function() {
                        $notification.fadeOut();
                    }, 3000);
                }
            }
            
            // Sync API keys from GitHub
            $('#ml-sync-api-keys').on('click', function() {
                var $btn = $(this);
                
                $btn.prop('disabled', true).text('Syncing...');
                showApiNotification('Fetching keys from GitHub...', 'info');
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_sync_api_keys',
                    nonce: mlAjax.nonce,
                    force: true
                }, function(response) {
                    if (response.success) {
                        showApiNotification('✓ ' + response.data.message, 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showApiNotification('✗ ' + response.data, 'error');
                    }
                }).fail(function() {
                    showApiNotification('✗ Sync failed', 'error');
                }).always(function() {
                    $btn.prop('disabled', false).text('Sync from GitHub');
                });
            });
            
            // Show input row
            $(document).on('click', '.ml-show-override-input', function() {
                var provider = $(this).data('provider');
                $('#input-row-' + provider).show();
                $('#ml-override-' + provider).focus();
            });
            
            // Cancel input
            $(document).on('click', '.ml-cancel-override', function() {
                var provider = $(this).data('provider');
                $('#input-row-' + provider).hide();
                $('#ml-override-' + provider).val('');
            });
            
            // Save override key
            $(document).on('click', '.ml-save-override', function() {
                var $btn = $(this);
                var provider = $btn.data('provider');
                var $input = $('#ml-override-' + provider);
                var key = $input.val().trim();
                
                if (!key) {
                    showApiNotification('Please enter an API key', 'error');
                    return;
                }
                
                $btn.prop('disabled', true).text('Saving...');
                showApiNotification('Saving API key...', 'info');
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_save_api_key_override',
                    nonce: mlAjax.nonce,
                    provider: provider,
                    key: key
                }, function(response) {
                    if (response.success) {
                        showApiNotification('✓ API key saved successfully', 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showApiNotification('✗ ' + response.data, 'error');
                        $btn.prop('disabled', false).text('Save');
                    }
                }).fail(function() {
                    showApiNotification('✗ Failed to save key', 'error');
                    $btn.prop('disabled', false).text('Save');
                });
            });
            
            // Save dual-key override (Noun Project: API Key + API Secret)
            $(document).on('click', '.ml-save-override-dual', function() {
                var $btn = $(this);
                var provider = $btn.data('provider');
                var $keyInput = $('#ml-override-' + provider + '-key');
                var $secretInput = $('#ml-override-' + provider + '-secret');
                var apiKey = $keyInput.val().trim();
                var apiSecret = $secretInput.val().trim();
                
                if (!apiKey || !apiSecret) {
                    showApiNotification('Please enter both API Key and API Secret', 'error');
                    return;
                }
                
                $btn.prop('disabled', true).text('Saving...');
                showApiNotification('Saving API keys...', 'info');
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_save_api_key_override_dual',
                    nonce: mlAjax.nonce,
                    provider: provider,
                    api_key: apiKey,
                    api_secret: apiSecret
                }, function(response) {
                    if (response.success) {
                        showApiNotification('✓ API keys saved successfully', 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showApiNotification('✗ ' + response.data, 'error');
                        $btn.prop('disabled', false).text('Save');
                    }
                }).fail(function() {
                    showApiNotification('✗ Failed to save keys', 'error');
                    $btn.prop('disabled', false).text('Save');
                });
            });
            
            // Remove override key
            $(document).on('click', '.ml-remove-override', function() {
                var $btn = $(this);
                var provider = $btn.data('provider');
                
                showNotification('Removing custom API key for ' + provider + '...', 'info');
                $btn.prop('disabled', true).text('Removing...');
                showApiNotification('Removing override...', 'info');
                
                $.post(mlAjax.ajaxurl, {
                    action: 'ml_remove_api_key_override',
                    nonce: mlAjax.nonce,
                    provider: provider
                }, function(response) {
                    if (response.success) {
                        showApiNotification('✓ Override removed', 'success');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showApiNotification('✗ ' + response.data, 'error');
                        $btn.prop('disabled', false).text('Remove');
                    }
                }).fail(function() {
                    showApiNotification('✗ Failed to remove override', 'error');
                    $btn.prop('disabled', false).text('Remove');
                });
            });
        });
        </script>
        <?php
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 9: DEMO PLUGINS
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function render_calculator_page() {
        ?>
        <div class="wrap">
            <h1>Demo Calculator - IT WORKS!</h1>
            <div style="background: white; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; margin-top: 20px;">
                <h2 style="color: green;">Virtual Plugin System Working!</h2>
                <p><strong>Plugin:</strong> Demo Calculator Widget</p>
                <p><strong>Version:</strong> 1.0.0</p>
                <p><strong>Status:</strong> <span style="color: green;">Running from GitHub (or demo fallback)</span></p>
                <p><strong>Code Location:</strong> Remote execution - no local files!</p>
                <hr>
                <h3>Simple Calculator:</h3>
                <input type="number" id="num1" placeholder="First number" style="margin: 5px; padding: 8px;">
                <select id="operator" style="margin: 5px; padding: 8px;">
                    <option value="+">+</option>
                    <option value="-">-</option>
                    <option value="*">×</option>
                    <option value="/">/</option>
                </select>
                <input type="number" id="num2" placeholder="Second number" style="margin: 5px; padding: 8px;">
                <button onclick="calculate()" class="button button-primary" style="margin: 5px;">Calculate</button>
                <div id="result" style="margin-top: 15px; padding: 10px; background: #f0f0f0; border-radius: 4px;">Result will appear here...</div>
            </div>
                <script>
            function calculate() {
                const num1 = parseFloat(document.getElementById('num1').value);
                const num2 = parseFloat(document.getElementById('num2').value);
                const operator = document.getElementById('operator').value;
                let result;
                        switch(operator) {
                    case '+': result = num1 + num2; break;
                    case '-': result = num1 - num2; break;
                    case '*': result = num1 * num2; break;
                    case '/': result = num2 !== 0 ? num1 / num2 : 'Error: Division by zero'; break;
                }
                        document.getElementById('result').innerHTML = '<strong>Result: ' + result + '</strong>';
            }
            </script>
        </div>
        <?php
    }
    
    public function render_test_plugin_page() {
        ?>
        <div class="wrap">
            <h1>Test Plugin Demo</h1>
            <div style="background: white; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; margin-top: 20px;">
                <h2 style="color: green;">SUCCESS! Virtual Plugin System is Working!</h2>
                <p>This plugin is running completely from remote code execution.</p>
                <p><strong>Current Time:</strong> <?php echo current_time('Y-m-d H:i:s'); ?></p>
                <p><strong>WordPress Version:</strong> <?php echo get_bloginfo('version'); ?></p>
                <p><strong>Plugin Status:</strong> <span style="color: green; font-weight: bold;">ACTIVE & RUNNING</span></p>
                <p><strong>Code Storage:</strong> <span style="color: blue;">Remote (GitHub or Demo)</span></p>
                <p><strong>Local Files:</strong> <span style="color: red;">NONE - Completely Virtual!</span></p>
                <hr>
                <h3>System Information:</h3>
                <ul>
                    <li><strong>Server:</strong> <?php echo $_SERVER['SERVER_SOFTWARE']; ?></li>
                    <li><strong>PHP Version:</strong> <?php echo PHP_VERSION; ?></li>
                    <li><strong>Memory Limit:</strong> <?php echo ini_get('memory_limit'); ?></li>
                    <li><strong>Execution Time:</strong> <?php echo microtime(true); ?></li>
                </ul>
            </div>
        </div>
        <?php
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 4: PLUGIN INVENTORY MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function load_virtual_plugins() {
        if (!$this->authenticated) {
            return;
        }
        // Fetch plugin inventory from GitHub
        $inventory = $this->fetch_plugin_inventory();
        if ($inventory) {
            $this->virtual_plugins = $inventory;
            update_option('ml_plugin_inventory', $inventory);
            // Register hooks for active plugins (disabled - using direct menu registration now)
        // $this->register_active_plugin_hooks();
        }
    }
    
    private function fetch_plugin_inventory() {
        // v4.0.7: Fetch inventory from PUBLIC relay repo (no token needed)
        $relay_inventory_url = 'https://raw.githubusercontent.com/wplaunchify/ml-plugin-manager-relay/main/inventory.json';
        error_log('MinuteLaunch: Fetching inventory from public relay: ' . $relay_inventory_url);
        
        $response = wp_remote_get($relay_inventory_url, [
            'timeout' => 15,
            'headers' => [
                'User-Agent' => 'ML-Plugin-Manager/' . MINUTELAUNCH_VERSION
            ]
        ]);
        
        if (is_wp_error($response)) {
            error_log('MinuteLaunch: Failed to fetch inventory - ' . $response->get_error_message());
            return $this->get_demo_inventory();
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('MinuteLaunch: Relay returned status ' . $response_code . ' for inventory.json');
            return $this->get_demo_inventory();
        }
        
        $inventory_data = wp_remote_retrieve_body($response);
        
        if (!$inventory_data) {
            error_log('MinuteLaunch: Empty inventory response from relay');
            return $this->get_demo_inventory();
        }
        
        error_log('MinuteLaunch: Received inventory data (first 200 chars): ' . substr($inventory_data, 0, 200));
        
        $inventory = json_decode($inventory_data, true);
        if (!$inventory) {
            error_log('MinuteLaunch: Failed to parse inventory.json - invalid JSON');
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p><strong>MinuteLaunch:</strong> Failed to parse inventory.json - showing demo plugins</p></div>';
            });
            return $this->get_demo_inventory();
        }
        
        error_log('MinuteLaunch: Raw inventory has ' . count($inventory['plugins']) . ' plugins');
        
        // Convert array format to associative array with slug keys
        if (isset($inventory['plugins']) && is_array($inventory['plugins'])) {
            $plugins_assoc = [];
            foreach ($inventory['plugins'] as $plugin) {
                if (isset($plugin['slug'])) {
                    $plugins_assoc[$plugin['slug']] = $plugin;
                }
            }
            $inventory['plugins'] = $plugins_assoc;
            error_log('MinuteLaunch: Converted to ' . count($plugins_assoc) . ' plugins');
        }
        
        // v4.0+: No tier filtering - all approved sites get all plugins
        error_log('MinuteLaunch: Successfully fetched inventory - ' . count($inventory['plugins']) . ' plugins available');
        return $inventory;
    }
    
    private function get_demo_inventory() {
        return [
            'plugins' => [
                'demo-calculator' => [
                    'name' => 'Demo Calculator Widget',
                    'description' => 'Simple calculator widget for testing the virtual plugin system',
                    'version' => '1.0.0',
                    'file' => 'demo-calculator-v1.0.0.php',
                    'category' => 'Demo',
                    'requires_wp' => '5.0',
                    'tested_up_to' => '6.4',
                    'license_tier' => 'free',
                    'auto_update' => true,
                    'hooks' => ['wp_ajax_demo_calculate', 'wp_ajax_nopriv_demo_calculate', 'admin_menu'],
                    'icon' => '🧮'
                ],
                'test-plugin' => [
                    'name' => 'Test Plugin Demo',
                    'description' => 'A simple test plugin to demonstrate the virtual system working',
                    'version' => '1.0.0',
                    'file' => 'test-plugin-v1.0.0.php',
                    'category' => 'Demo',
                    'requires_wp' => '5.0',
                    'tested_up_to' => '6.4',
                    'license_tier' => 'free',
                    'auto_update' => true,
                    'hooks' => ['admin_menu'],
                    'icon' => '🔌'
                ]
            ],
            'last_updated' => date('c'),
            'total_plugins' => 2,
            'repository_version' => '1.0.0-demo'
        ];
    }
    
    private function register_active_plugin_hooks() {
        // DISABLED - Causing class conflicts
        // Using direct menu registration instead
        return;
    }
    
    public function render_admin_page() {
        // v4.0.0: Always "logged in" - no token needed!
        $is_logged_in = true;
        $inventory = $this->fetch_plugin_inventory(); // Always fetch inventory
        
        // Fetch remote announcements
        $announcements = $this->fetch_announcements();
        ?>
        <div class="wrap">
            <!-- This h1 is required for WordPress to inject notices above (they appear after the first h1) -->
            <h1 class="wp-heading-inline" style="margin: 0; padding: 0; font-size: 0; line-height: 0; height: 0; overflow: hidden;">MinuteLaunch Plugin Manager</h1>
            <!-- WordPress admin notices will be injected here automatically -->
        </div>
        
        <!-- MinuteLaunch container (separate from WordPress notices area) -->
        <div class="wrap ml-wrap">
            <!-- MinuteLaunch-specific notifications (kept separate from WordPress notices) -->
            <div id="ml-notification" class="ml-notification" style="display: none;"></div>
            
            <!-- Remote Announcements -->
            <?php if (!empty($announcements)): ?>
                <?php foreach ($announcements as $announcement): ?>
                    <div class="notice notice-<?php echo esc_attr($announcement['severity'] === 'high' ? 'error' : ($announcement['severity'] === 'medium' ? 'warning' : 'info')); ?> ml-announcement" data-announcement-id="<?php echo esc_attr($announcement['id']); ?>" style="position: relative; padding-right: 38px;">
                        <p>
                            <strong><?php echo esc_html($announcement['title']); ?></strong><br>
                            <?php echo esc_html($announcement['message']); ?>
                            <?php if (!empty($announcement['action_text'])): ?>
                                <br><br>
                                <button type="button" class="button button-primary ml-announcement-action" data-action="<?php echo esc_attr($announcement['action_type']); ?>">
                                    <?php echo esc_html($announcement['action_text']); ?>
                                </button>
                            <?php endif; ?>
                        </p>
                        <?php if ($announcement['dismissible']): ?>
                            <button type="button" class="notice-dismiss ml-dismiss-announcement"><span class="screen-reader-text">Dismiss</span></button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <!-- Header with login/logout -->
            <div class="ml-header">
                <div class="ml-header-left">
                    <img src="https://raw.githubusercontent.com/wplaunchify/ml-assets/main/min-launch-no-grey-no-shadow.png" class="ml-header-logo" style="width: 48px; height: 48px;" alt="MinuteLaunch">
                    <div class="ml-header-text">
                    <h2 style="margin: 0; font-size: 23px; font-weight: 400; line-height: 1.3;">MinuteLaunch Plugin Manager <span style="font-size: 14px; color: #666; font-weight: 300;">v<?php echo MINUTELAUNCH_VERSION; ?></span></h2>
                    <p class="ml-tagline">Manage your virtual plugin collection</p>
                    </div>
                </div>
                <div class="ml-header-right">
                    <!-- v4.0.0: No login needed! -->
                    <div class="ml-user-info">
                        <span class="ml-user-email" style="color: #46b450; font-weight: 600;">✅ Active</span>
                        <button type="button" id="ml-check-updates-btn" class="button button-primary" style="margin-left: 12px;">
                            <span class="dashicons dashicons-update" style="margin-top: 3px;"></span> Check for Updates
                        </button>
                    </div>
                </div>
            </div>

            <!-- v4.0.0: Always show plugins - no login needed! -->
            <div class="ml-content">
                <div class="ml-toolbar">
                    <button id="ml-refresh-inventory" class="button button-primary">Refresh Plugin List</button>
                    <button id="ml-clear-all-caches" class="button" style="margin-left: 10px;">🔄 Clear All Caches</button>
                    <span class="ml-toolbar-info">Fetch latest plugins and updates from GitHub</span>
                </div>
                        <div class="plugin-browser">
                    <?php if (empty($inventory['plugins'])): ?>
                        <div class="ml-empty-state">
                            <p>No plugins available. Click "Refresh Plugin List" to load your plugins.</p>
                        </div>
                    <?php else: ?>
                        <table class="wp-list-table widefat plugins ml-plugin-table" id="ml-plugins-table">
                            <thead>
                                <tr>
                                    <th style="width: 50%; cursor: pointer;" data-sort="name">Plugin <span class="sort-indicator"></span></th>
                                    <th style="cursor: pointer;" data-sort="version">Version <span class="sort-indicator"></span></th>
                                    <th style="cursor: pointer;" data-sort="category">Category <span class="sort-indicator"></span></th>
                                    <th style="text-align: right;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($inventory['plugins'] as $slug => $plugin): ?>
                                <tr data-name="<?php echo esc_attr(strtolower($plugin['name'])); ?>" data-version="<?php echo esc_attr($plugin['version']); ?>" data-category="<?php echo esc_attr(strtolower($plugin['category'])); ?>">
                                    <td>
                                        <div class="plugin-name">
                                            <div>
                                                <strong><?php echo esc_html($plugin['name']); ?></strong>
                                                <?php if ($this->is_plugin_active($slug)): ?>
                                                    <span class="plugin-status active">Active</span>
                                                <?php else: ?>
                                                    <span class="plugin-status inactive">Inactive</span>
                                                <?php endif; ?>
                                                <div class="plugin-description"><?php echo esc_html($plugin['description']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo esc_html($plugin['version']); ?></td>
                                    <td><?php echo esc_html($plugin['category']); ?></td>
                                    <td style="text-align: right;">
                                        <?php if ($this->is_plugin_active($slug)): ?>
                                            <button class="button button-secondary ml-deactivate" data-plugin="<?php echo esc_attr($slug); ?>">
                                                Deactivate
                                            </button>
                                        <?php else: ?>
                                            <button class="button button-primary ml-activate" data-plugin="<?php echo esc_attr($slug); ?>">
                                                Activate
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- PHYSICAL PLUGINS SECTION -->
                <div class="ml-physical-plugins" style="margin-top: 40px;">
                    <h2 style="font-size: 20px; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #E55B10;">
                        📦 Physical Plugins
                    </h2>
                    <p style="color: #666; margin-bottom: 20px;">
                        These are full WordPress plugins that install to your site. They remain installed even if you stop your MinuteLaunch subscription.
                    </p>
                    
                    <?php
                    // Get physical plugins from inventory.json (reuse existing $inventory from render_admin_page)
                    $physical_plugins = [];
                    
                    if (isset($inventory['plugins']) && is_array($inventory['plugins'])) {
                        foreach ($inventory['plugins'] as $slug => $plugin) {
                            if (isset($plugin['type']) && $plugin['type'] === 'physical') {
                                $physical_plugins[] = $plugin;
                            }
                        }
                    }
                    
                    // Fallback to hardcoded if inventory fetch failed
                    if (empty($physical_plugins)) {
                        $physical_plugins = [
                            [
                                'slug' => 'ml-canvas-block',
                                'name' => 'ML Canvas Block',
                                'description' => 'Custom Gutenberg block for full-control HTML/CSS pages with Kadence integration. LLM-friendly REST API included.',
                                'version' => '2.7.8',
                                'repository' => 'wplaunchify/ml-canvas-block',
                                'zip_file' => 'ml-canvas-block.zip'
                            ]
                        ];
                    }
                    
                    foreach ($physical_plugins as $plugin):
                        // WordPress creates folder: ml-canvas-block/ml-canvas-block.php
                        $plugin_file = $plugin['slug'] . '/' . $plugin['slug'] . '.php';
                        // Check if plugin file exists
                        $is_installed = file_exists(WP_PLUGIN_DIR . '/' . $plugin_file);
                        $is_active = is_plugin_active($plugin_file);
                        
                        // Get installed version
                        $installed_version = '';
                        $needs_update = false;
                        if ($is_installed) {
                            require_once ABSPATH . 'wp-admin/includes/plugin.php';
                            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file);
                            $installed_version = $plugin_data['Version'] ?? '';
                            if ($installed_version && version_compare($installed_version, $plugin['version'], '<')) {
                                $needs_update = true;
                            }
                        }
                    ?>
                    <div class="ml-physical-plugin-card" style="background: white; border: 1px solid #ddd; border-radius: 4px; padding: 20px; margin-bottom: 15px;">
                        <div style="display: flex; justify-content: space-between; align-items: start;">
                            <div style="flex: 1;">
                                <h3 style="margin: 0 0 10px 0; font-size: 16px;">
                                    <?php echo esc_html($plugin['name']); ?>
                                    <?php if ($is_active): ?>
                                        <span style="background: #46b450; color: white; padding: 2px 8px; border-radius: 3px; font-size: 12px; margin-left: 8px;">Active</span>
                                    <?php elseif ($is_installed): ?>
                                        <span style="background: #999; color: white; padding: 2px 8px; border-radius: 3px; font-size: 12px; margin-left: 8px;">Installed</span>
                                    <?php endif; ?>
                                    <?php if ($needs_update): ?>
                                        <span style="background: #f56e28; color: white; padding: 2px 8px; border-radius: 3px; font-size: 12px; margin-left: 8px;">Update Available</span>
                                    <?php endif; ?>
                                </h3>
                                <p style="margin: 0 0 10px 0; color: #666;">
                                    <?php echo esc_html($plugin['description']); ?>
                                </p>
                                <p style="margin: 0; font-size: 13px; color: #999;">
                                    <?php if ($installed_version): ?>
                                        Installed: <?php echo esc_html($installed_version); ?> | 
                                    <?php endif; ?>
                                    Latest: <?php echo esc_html($plugin['version']); ?>
                                </p>
                            </div>
                            <div style="margin-left: 20px;">
                                <?php if ($is_active && $needs_update): ?>
                                    <button class="button button-primary ml-install-physical" 
                                            data-slug="<?php echo esc_attr($plugin['slug']); ?>"
                                            data-repo="<?php echo esc_attr($plugin['repository']); ?>"
                                            data-zip="<?php echo esc_attr($plugin['zip_file']); ?>">
                                        Update to <?php echo esc_html($plugin['version']); ?>
                                    </button>
                                <?php elseif ($is_active): ?>
                                    <a href="<?php echo admin_url('plugins.php'); ?>" class="button" target="_blank">
                                        Manage in Plugins
                                    </a>
                                <?php elseif ($is_installed): ?>
                                    <button class="button button-primary ml-activate-physical" 
                                            data-plugin="<?php echo esc_attr($plugin_file); ?>">
                                        Activate Plugin
                                    </button>
                                <?php else: ?>
                                    <button class="button button-primary ml-install-physical" 
                                            data-slug="<?php echo esc_attr($plugin['slug']); ?>"
                                            data-repo="<?php echo esc_attr($plugin['repository']); ?>"
                                            data-zip="<?php echo esc_attr($plugin['zip_file']); ?>">
                                        Install Plugin
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- API KEYS SECTION -->
                <div class="ml-api-keys-section" style="margin-top: 40px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h2 style="font-size: 20px; margin: 0; padding-bottom: 10px; border-bottom: 2px solid #E55B10;">
                            🔑 API Key Manager
                        </h2>
                        <div>
                            <button id="ml-sync-api-keys" class="button">Sync from GitHub</button>
                        </div>
                    </div>
                    
                    <!-- Inline notification area -->
                    <div id="ml-api-notification" style="display: none; padding: 12px 15px; margin-bottom: 15px; border-radius: 4px; border-left: 4px solid;"></div>
                    
                    <?php $this->render_api_keys_interface(); ?>
                </div>

            </div>
        </div>
        <?php
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // API KEY MANAGER UI
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function render_api_keys_interface() {
        $central_keys = get_option('ml_central_api_keys', array());
        $overrides = get_option('ml_api_key_overrides', array());
        
        if (empty($central_keys)) {
            echo '<div style="background: #d1ecf1; border-left: 4px solid #0c5460; padding: 12px 15px; margin: 20px 0; border-radius: 4px; color: #0c5460;">';
            echo 'No API keys loaded. Click "Sync from GitHub" to fetch keys.';
            echo '</div>';
            return;
        }
        
        $keys = $central_keys['keys'] ?? array();
        
        // Separate managed vs client keys
        $managed_keys = array_filter($keys, function($key_data) {
            return ($key_data['managed_by'] ?? '') === 'minutelaunch';
        });
        
        $client_keys = array_filter($keys, function($key_data) {
            return ($key_data['managed_by'] ?? '') === 'client';
        });
        
        // Combine and sort alphabetically
        $all_keys = array_merge($managed_keys, $client_keys);
        ksort($all_keys);
        
        // Render table
        echo '<table class="ml-api-keys-table" style="margin-top: 20px; width: 100%; border-collapse: collapse; background: white;">';
        echo '<thead><tr style="background: #f9f9f9; border-bottom: 1px solid #ddd;">';
        echo '<th style="padding: 12px; text-align: left; font-weight: 600; width: 20%;">Provider</th>';
        echo '<th style="padding: 12px; text-align: left; font-weight: 600; width: 10%;">Status</th>';
        echo '<th style="padding: 12px; text-align: left; font-weight: 600; width: 40%;">Used By</th>';
        echo '<th style="padding: 12px; text-align: right; font-weight: 600; width: 30%;">Actions</th>';
        echo '</tr></thead>';
        echo '<tbody>';
        
        $row_num = 0;
        foreach ($all_keys as $provider => $key_data) {
            $this->render_api_key_card($provider, $key_data, $overrides, $row_num++);
        }
        
        echo '</tbody></table>';
    }
    
    private function render_api_key_card($provider, $key_data, $overrides, $row_num) {
        $is_managed = ($key_data['managed_by'] ?? '') === 'minutelaunch';
        $has_central_key = !empty($key_data['key']) || (!empty($key_data['api_key']) && !empty($key_data['api_secret']));
        $has_override = isset($overrides[$provider]);
        $is_dual_key = isset($key_data['api_key']) && isset($key_data['api_secret']); // Noun Project uses dual keys
        
        // Status text
        if ($has_override) {
            $status = 'Override';
            $status_color = '#666';
        } elseif ($has_central_key) {
            $status = 'Active';
            $status_color = '#46b450';
        } else {
            $status = '—';
            $status_color = '#999';
        }
        
        // Alternating row colors
        $bg_color = ($row_num % 2 === 0) ? '#ffffff' : '#f9f9f9';
        
        ?>
        <tr style="background: <?php echo $bg_color; ?>; border-bottom: 1px solid #e5e5e5;">
            <td style="padding: 12px;"><?php echo esc_html($key_data['provider']); ?></td>
            <td style="padding: 12px; color: <?php echo $status_color; ?>;"><?php echo $status; ?></td>
            <td style="padding: 12px; color: #666;">
                <?php echo !empty($key_data['used_by_plugins']) ? implode(', ', $key_data['used_by_plugins']) : '—'; ?>
            </td>
            <td style="padding: 12px; text-align: right;">
                <?php if ($has_override): ?>
                    <button class="button ml-btn-fixed ml-btn-override ml-remove-override" data-provider="<?php echo esc_attr($provider); ?>">
                        Remove
                    </button>
                <?php elseif ($has_central_key): ?>
                    <button class="button ml-btn-fixed ml-btn-active ml-show-override-input" data-provider="<?php echo esc_attr($provider); ?>">
                        Override
                    </button>
                <?php else: ?>
                    <button class="button ml-btn-fixed ml-btn-add ml-show-override-input" data-provider="<?php echo esc_attr($provider); ?>">
                        Add
                    </button>
                <?php endif; ?>
                <a href="<?php echo esc_url($key_data['get_your_own_url']); ?>" target="_blank" class="button ml-btn-fixed ml-btn-get">
                    Get Key
                </a>
            </td>
        </tr>
        <tr class="ml-key-input-row" id="input-row-<?php echo esc_attr($provider); ?>" style="display: none; background: #f0f0f0;">
            <td colspan="4" style="padding: 12px; border-bottom: 1px solid #e5e5e5;">
                <?php if ($is_dual_key): ?>
                    <!-- Noun Project: Dual key input (API Key + API Secret) -->
                    <div style="margin-bottom: 8px;">
                        <label style="display: inline-block; width: 100px; font-weight: 600;">API Key:</label>
                        <input type="password" 
                               id="ml-override-<?php echo esc_attr($provider); ?>-key" 
                               class="regular-text" 
                               placeholder="API Key"
                               style="font-family: monospace;">
                    </div>
                    <div style="margin-bottom: 12px;">
                        <label style="display: inline-block; width: 100px; font-weight: 600;">API Secret:</label>
                        <input type="password" 
                               id="ml-override-<?php echo esc_attr($provider); ?>-secret" 
                               class="regular-text" 
                               placeholder="API Secret"
                               style="font-family: monospace;">
                    </div>
                    <button class="button button-primary ml-save-override-dual" data-provider="<?php echo esc_attr($provider); ?>">
                        Save
                    </button>
                    <button class="button ml-cancel-override" data-provider="<?php echo esc_attr($provider); ?>">
                        Cancel
                    </button>
                <?php else: ?>
                    <!-- Standard: Single key input -->
                    <input type="password" 
                           id="ml-override-<?php echo esc_attr($provider); ?>" 
                           class="regular-text" 
                           placeholder="API key"
                           style="font-family: monospace; margin-right: 8px;">
                    <button class="button button-primary ml-save-override" data-provider="<?php echo esc_attr($provider); ?>">
                        Save
                    </button>
                    <button class="button ml-cancel-override" data-provider="<?php echo esc_attr($provider); ?>">
                        Cancel
                    </button>
                <?php endif; ?>
            </td>
        </tr>
        <?php
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 6: PLUGIN ACTIVATION/DEACTIVATION
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function toggle_virtual_plugin() {
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        $plugin_slug = sanitize_text_field($_POST['plugin']);
        $action = sanitize_text_field($_POST['toggle_action']);
        
        // Check if this is a physical plugin (contains /)
        if (strpos($plugin_slug, '/') !== false) {
            // Physical plugin - use WordPress native activation
            if ($action === 'activate') {
                $result = activate_plugin($plugin_slug);
                if (is_wp_error($result)) {
                    wp_send_json_error($result->get_error_message());
                } else {
                    wp_send_json_success('Plugin activated successfully');
                }
            } else {
                deactivate_plugins($plugin_slug);
                wp_send_json_success('Plugin deactivated successfully');
            }
            return;
        }
        
        // Virtual plugin - use custom activation
        $active_plugins = get_option('ml_active_plugins', []);
        if ($action === 'activate') {
            if (!in_array($plugin_slug, $active_plugins)) {
                $active_plugins[] = $plugin_slug;
                update_option('ml_active_plugins', $active_plugins);
                        // Register hooks for this plugin
                $this->register_single_plugin_hooks($plugin_slug);
                        wp_send_json_success('Plugin activated successfully');
            } else {
                wp_send_json_error('Plugin is already active');
            }
        } else {
            $active_plugins = array_diff($active_plugins, [$plugin_slug]);
            update_option('ml_active_plugins', $active_plugins);
                // Clear the transient cache for this plugin so it doesn't load on next request
            $cache_key = 'ml_plugin_code_' . md5($plugin_slug);
            delete_transient($cache_key);
            
            // CACHE BUSTING: Clear opcache when deactivating
            if (function_exists('opcache_reset')) {
                opcache_reset();
                error_log("MinuteLaunch: Cleared opcache after deactivating {$plugin_slug}");
            }
                wp_send_json_success('Plugin deactivated successfully. Please refresh the page to complete deactivation.');
        }
    }
    
    private function register_single_plugin_hooks($plugin_slug) {
        if (!isset($this->virtual_plugins['plugins'][$plugin_slug])) {
            return;
        }
        $plugin_info = $this->virtual_plugins['plugins'][$plugin_slug];
        if (isset($plugin_info['hooks'])) {
            foreach ($plugin_info['hooks'] as $hook) {
                add_action($hook, function() use ($plugin_slug, $hook) {
                    $this->execute_virtual_plugin_hook($plugin_slug, $hook, func_get_args());
                }, 10, 0);
            }
        }
        // DISABLED - Causing class conflicts
    }
    
    public function execute_virtual_plugin_hook($plugin_slug, $hook, $args = []) {
        // DISABLED - Causing class conflicts with DemoCalculatorTest
        // Using direct menu registration instead
        return false;
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 7: WORDPRESS INTEGRATION
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function add_virtual_plugins_to_list($plugins) {
        $active_plugins = get_option('ml_active_plugins', []);
        $inventory = get_option('ml_plugin_inventory', []);
        if (empty($inventory['plugins'])) {
            return $plugins;
        }
        
        // Sort plugins alphabetically for consistent display order
        sort($active_plugins);
        
        foreach ($active_plugins as $plugin_slug) {
            if (!isset($inventory['plugins'][$plugin_slug])) {
                continue;
            }
                $plugin_info = $inventory['plugins'][$plugin_slug];
            $virtual_key = "minutelaunch-virtual/{$plugin_slug}.php";
                $plugins[$virtual_key] = [
                'Name' => str_replace(['Demo ', 'Widget', 'System'], '', $plugin_info['name']),
                'Description' => 'MinuteLaunch virtual plugin - ' . $plugin_info['description'] . ' | Managed through MinuteLaunch interface.',
                'Version' => $plugin_info['version'],
                'Author' => 'MinuteLaunch',
                'AuthorURI' => 'https://minutelaunch.com',
                'PluginURI' => 'https://minutelaunch.com',
                'TextDomain' => 'minutelaunch',
                'DomainPath' => '',
                'Network' => false,
                'Title' => str_replace(['Demo ', 'Widget', 'System'], '', $plugin_info['name']),
                'AuthorName' => 'MinuteLaunch'
            ];
        }
        return $plugins;
    }
    
    public function add_virtual_to_active_list($active_plugins) {
        $ml_active_plugins = get_option('ml_active_plugins', []);
        $inventory = get_option('ml_plugin_inventory', []);
        if (empty($inventory['plugins'])) {
            return $active_plugins;
        }
        
        // Sort ML plugins alphabetically
        sort($ml_active_plugins);
        
        // Add our virtual plugins to the active list so WordPress shows them as "Active"
        foreach ($ml_active_plugins as $plugin_slug) {
            if (isset($inventory['plugins'][$plugin_slug])) {
                $virtual_key = "minutelaunch-virtual/{$plugin_slug}.php";
                if (!in_array($virtual_key, $active_plugins)) {
                    $active_plugins[] = $virtual_key;
                }
            }
        }
        return $active_plugins;
    }
    
    public function bypass_virtual_plugin_validation($valid, $plugin_file) {
        // If this is one of our virtual plugins, tell WordPress it's valid
        if (strpos($plugin_file, 'minutelaunch-virtual/') === 0) {
            return 0; // Return 0 (no error) to indicate the plugin is valid
        }
        return $valid;
    }
    
    public function bypass_virtual_file_validation($valid, $file) {
        // Bypass validation for virtual plugin files
        if (strpos($file, 'minutelaunch-virtual/') === 0) {
            return 0; // Valid
        }
        return $valid;
    }
    
    public function suppress_virtual_plugin_notices() {
        // Remove plugin deactivation notices for virtual plugins
        $current_user_id = get_current_user_id();
        $dismissed = get_user_meta($current_user_id, 'dismissed_wp_pointers', true);
        // Clear any deactivated plugin notices for virtual plugins
        if (isset($_GET['deactivated']) && isset($_GET['plugin'])) {
            $plugin = $_GET['plugin'];
            if (strpos($plugin, 'minutelaunch-virtual/') === 0) {
                // Redirect without the error parameters
                wp_redirect(admin_url('admin.php?page=minutelaunch-plugins'));
                exit;
            }
        }
        // Remove the plugin_file_not_found transient for our virtual plugins
        global $wpdb;
        $transients = $wpdb->get_col(
            "SELECT option_name FROM $wpdb->options 
            WHERE option_name LIKE '_transient_plugin_slugs_%' 
            OR option_name LIKE '_transient_plugin_file_%'"
        );
        foreach ($transients as $transient) {
            delete_transient(str_replace('_transient_', '', $transient));
        }
    }
    
    public function remove_virtual_plugin_error_notices() {
        // Remove admin notices about virtual plugins not existing
        global $wp_filter;
        if (isset($wp_filter['admin_notices'])) {
            foreach ($wp_filter['admin_notices']->callbacks as $priority => $callbacks) {
                foreach ($callbacks as $key => $callback) {
                    // Remove any notices about plugin files not existing for virtual plugins
                    if (is_array($callback['function']) && 
                        isset($callback['function'][1]) && 
                        $callback['function'][1] === 'admin_notices') {
                        // We'll capture and filter the output instead
                        continue;
                    }
                }
            }
        }
        // Start output buffering to catch and filter error notices
        ob_start(function($buffer) {
            // Remove error messages about minutelaunch-virtual plugins
            $buffer = preg_replace(
                '/<div[^>]*class="[^"]*error[^"]*"[^>]*>.*?minutelaunch-virtual.*?<\/div>/is',
                '',
                $buffer
            );
                // Also remove notices about plugin deactivation for virtual plugins
            $buffer = preg_replace(
                '/<div[^>]*class="[^"]*notice[^"]*"[^>]*>.*?Plugin file does not exist.*?minutelaunch-virtual.*?<\/div>/is',
                '',
                $buffer
            );
                return $buffer;
        });
    }
    
    public function prevent_virtual_plugin_deactivation($plugin) {
        // If a virtual plugin was deactivated by WordPress, reactivate it silently
        if (strpos($plugin, 'minutelaunch-virtual/') === 0) {
            $active_plugins = get_option('active_plugins', []);
            if (!in_array($plugin, $active_plugins)) {
                $active_plugins[] = $plugin;
                update_option('active_plugins', $active_plugins);
            }
        }
    }
    
    public function hide_virtual_plugin_errors($plugin_meta, $plugin_file) {
        // Remove error messages from plugin row for virtual plugins
        if (strpos($plugin_file, 'minutelaunch-virtual/') === 0) {
            return [];
        }
        return $plugin_meta;
    }
    
    public function filter_active_plugins_for_loading($active_plugins) {
        // Prevent recursion - only filter once
        static $filtered = false;
        if ($filtered) {
            return $active_plugins;
        }
        $filtered = true;
        // Get the actual active_plugins from database
        if ($active_plugins === false) {
            remove_filter('pre_option_active_plugins', [$this, 'filter_active_plugins_for_loading'], 1);
            $active_plugins = get_option('active_plugins', []);
            add_filter('pre_option_active_plugins', [$this, 'filter_active_plugins_for_loading'], 1);
        }
        // Remove virtual plugins from the list WordPress tries to include()
        $result = [];
        foreach ((array)$active_plugins as $plugin) {
            if (strpos($plugin, 'minutelaunch-virtual/') !== 0) {
                $result[] = $plugin;
            }
        }
        return $result;
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 5: VIRTUAL PLUGIN LOADING (CORE FUNCTIONALITY + SAFETY VALVES)
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function load_virtual_plugins_early() {
        // Prevent loading multiple times
        static $loaded = false;
        if ($loaded) {
            return;
        }
        $loaded = true;
        
        // ═══════════════════════════════════════════════════════════════════════════
        // SAFETY VALVE #1: URL Parameter Override (?ml_safe_mode=1)
        // ═══════════════════════════════════════════════════════════════════════════
        if (isset($_GET['ml_safe_mode']) && $_GET['ml_safe_mode'] == '1') {
            error_log('MinuteLaunch: SAFE MODE ENABLED via URL parameter - skipping all virtual plugins');
            add_action('admin_notices', function() {
                echo '<div class="notice notice-warning is-dismissible">';
                echo '<p><strong>MinuteLaunch Safe Mode:</strong> All virtual plugins are temporarily disabled. ';
                echo '<a href="' . admin_url('admin.php?page=minutelaunch-plugins') . '">Manage plugins</a> or ';
                echo '<a href="' . remove_query_arg('ml_safe_mode') . '">Exit Safe Mode</a></p>';
                echo '</div>';
            });
            return;
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // SAFETY VALVE #2: Emergency Disable File (ml-emergency-disable.txt)
        // ═══════════════════════════════════════════════════════════════════════════
        $emergency_file = $this->plugin_path . 'ml-emergency-disable.txt';
        if (file_exists($emergency_file)) {
            error_log('MinuteLaunch: EMERGENCY DISABLE FILE DETECTED - skipping all virtual plugins');
            add_action('admin_notices', function() use ($emergency_file) {
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p><strong>MinuteLaunch Emergency Mode:</strong> All virtual plugins are disabled due to emergency file. ';
                echo 'Delete <code>ml-emergency-disable.txt</code> from the plugin directory to re-enable. ';
                echo '<a href="' . admin_url('admin.php?page=minutelaunch-plugins') . '">Manage plugins</a></p>';
                echo '</div>';
            });
            return;
        }
        
        if (!$this->authenticated) {
            return;
        }
        
        // Get inventory and load virtual plugins
        $this->virtual_plugins = get_option('ml_plugin_inventory', []);
        $ml_active_plugins = get_option('ml_active_plugins', []);
        if (empty($this->virtual_plugins['plugins']) || empty($ml_active_plugins)) {
            return;
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // SAFETY VALVE #3: Auto-Disable on Repeated Failures
        // ═══════════════════════════════════════════════════════════════════════════
        $failed_plugins = get_option('ml_failed_plugins', []);
        
        foreach ($ml_active_plugins as $plugin_slug) {
            if (!isset($this->virtual_plugins['plugins'][$plugin_slug])) {
                continue;
            }
            
            // Skip demo plugins (they're loaded via admin_menu)
            if ($plugin_slug === 'demo-calculator' || $plugin_slug === 'test-plugin') {
                continue;
            }
            
            // SAFETY VALVE #3: Skip plugins that have failed recently
            if (isset($failed_plugins[$plugin_slug])) {
                $fail_time = $failed_plugins[$plugin_slug]['time'];
                $fail_count = $failed_plugins[$plugin_slug]['count'];
                
                // If failed more than 3 times in last hour, skip it
                if ($fail_count >= 3 && (time() - $fail_time) < HOUR_IN_SECONDS) {
                    error_log("MinuteLaunch: Skipping {$plugin_slug} - failed {$fail_count} times recently");
                    continue;
                }
                
                // Reset counter after 1 hour
                if ((time() - $fail_time) >= HOUR_IN_SECONDS) {
                    unset($failed_plugins[$plugin_slug]);
                    update_option('ml_failed_plugins', $failed_plugins);
                }
            }
            
            // Check if already loaded to prevent duplicate loading
            if (defined('ML_LOADED_' . strtoupper(str_replace('-', '_', $plugin_slug)))) {
                continue;
            }
            
            $plugin_info = $this->virtual_plugins['plugins'][$plugin_slug];
            
            // Use transient cache to avoid fetching from GitHub on every request
            // Cache key uses md5 of slug only (not version) for seamless updates
            $cache_key = 'ml_plugin_code_' . md5($plugin_slug);
            $plugin_code = get_transient($cache_key);
            
            if ($plugin_code === false) {
                $plugin_code = $this->fetch_plugin_code($plugin_info['file']);
                if ($plugin_code) {
                    // Cache for 1 hour
                    set_transient($cache_key, $plugin_code, HOUR_IN_SECONDS);
                    
                    // CACHE BUSTING: Clear opcache when fetching fresh code
                    if (function_exists('opcache_reset')) {
                        opcache_reset();
                        error_log("MinuteLaunch: Cleared opcache after fetching {$plugin_slug}");
                    }
                }
            }
            
            if ($plugin_code) {
                // ═══════════════════════════════════════════════════════════════════
                // ENHANCED SAFETY WRAPPER v2.3.0
                // Catches ALL errors including fatal errors that would crash the site
                // ═══════════════════════════════════════════════════════════════════
                
                // Register shutdown function to catch fatal errors BEFORE they crash
                $shutdown_handler = function() use ($plugin_slug, &$failed_plugins) {
                    $error = error_get_last();
                    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
                        error_log("MinuteLaunch: FATAL ERROR CAUGHT in {$plugin_slug} - {$error['message']} in {$error['file']}:{$error['line']}");
                        
                        // Track the failure
                        if (!isset($failed_plugins[$plugin_slug])) {
                            $failed_plugins[$plugin_slug] = ['count' => 0, 'time' => time(), 'error' => ''];
                        }
                        $failed_plugins[$plugin_slug]['count']++;
                        $failed_plugins[$plugin_slug]['time'] = time();
                        $failed_plugins[$plugin_slug]['error'] = $error['message'];
                        update_option('ml_failed_plugins', $failed_plugins);
                        
                        // Clear the bad code from cache
                        $cache_key = 'ml_plugin_code_' . md5($plugin_slug);
                        delete_transient($cache_key);
                        
                        error_log("MinuteLaunch: Auto-disabled {$plugin_slug} and cleared cache");
                    }
                };
                
                register_shutdown_function($shutdown_handler);
                
                try {
                    // Mark as loaded
                    define('ML_LOADED_' . strtoupper(str_replace('-', '_', $plugin_slug)), true);
                    
                    // Set error handler to convert warnings/notices to exceptions
                    set_error_handler(function($errno, $errstr, $errfile, $errline) use ($plugin_slug) {
                        // Only throw for serious errors (not notices/warnings)
                        if ($errno === E_ERROR || $errno === E_PARSE || $errno === E_CORE_ERROR || $errno === E_COMPILE_ERROR) {
                            throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
                        }
                        // Log but don't throw for warnings
                        error_log("MinuteLaunch: Warning in {$plugin_slug}: {$errstr}");
                        return true;
                    });
                    
                    // Execute in global scope with output buffering
                    ob_start();
                    eval('?>' . $plugin_code);
                    $output = ob_get_clean();
                    
                    restore_error_handler();
                    
                    // Success - clear any previous failures
                    if (isset($failed_plugins[$plugin_slug])) {
                        unset($failed_plugins[$plugin_slug]);
                        update_option('ml_failed_plugins', $failed_plugins);
                        error_log("MinuteLaunch: {$plugin_slug} loaded successfully, cleared previous failures");
                    }
                    
                } catch (Throwable $e) {
                    restore_error_handler();
                    ob_end_clean();
                    
                    // Log the error
                    error_log("MinuteLaunch: EXCEPTION in {$plugin_slug}: " . $e->getMessage());
                    error_log("MinuteLaunch: Stack trace: " . $e->getTraceAsString());
                    
                    // Track the failure
                    if (!isset($failed_plugins[$plugin_slug])) {
                        $failed_plugins[$plugin_slug] = ['count' => 0, 'time' => time(), 'error' => ''];
                    }
                    $failed_plugins[$plugin_slug]['count']++;
                    $failed_plugins[$plugin_slug]['time'] = time();
                    $failed_plugins[$plugin_slug]['error'] = $e->getMessage();
                    update_option('ml_failed_plugins', $failed_plugins);
                    
                    // Clear the bad code from cache
                    $cache_key = 'ml_plugin_code_' . md5($plugin_slug);
                    delete_transient($cache_key);
                    
                    // Show admin notice
                    add_action('admin_notices', function() use ($plugin_slug, $e, $failed_plugins) {
                        $fail_count = $failed_plugins[$plugin_slug]['count'] ?? 1;
                        $status_class = $fail_count >= 3 ? 'notice-error' : 'notice-warning';
                        $status_text = $fail_count >= 3 ? 'AUTO-DISABLED' : 'ERROR';
                        
                        echo '<div class="notice ' . $status_class . ' is-dismissible">';
                        echo '<p><strong>MinuteLaunch ' . $status_text . ':</strong> Plugin <code>' . esc_html($plugin_slug) . '</code> ';
                        if ($fail_count >= 3) {
                            echo 'has been automatically disabled after ' . $fail_count . ' failures.';
                        } else {
                            echo 'failed to load (attempt ' . $fail_count . '/3).';
                        }
                        echo '</p>';
                        echo '<p>Error: ' . esc_html($e->getMessage()) . '</p>';
                        echo '<p><a href="' . admin_url('admin.php?page=minutelaunch-plugins') . '">Manage Plugins</a> | ';
                        echo '<a href="' . add_query_arg('ml_safe_mode', '1') . '">Enter Safe Mode</a></p>';
                        echo '</div>';
                    });
                }
            }
        }
    }
    
    public function modify_virtual_plugin_actions($actions, $plugin_file) {
        // Check if this is one of our virtual plugins
        if (strpos($plugin_file, 'minutelaunch-virtual/') === 0) {
            // Remove ALL default actions that don't make sense for virtual plugins
            unset($actions['edit']);
            unset($actions['deactivate']);
            unset($actions['activate']);
            unset($actions['delete']);
                // Add custom action that redirects to MinuteLaunch
            $actions['manage'] = '<a href="' . admin_url('admin.php?page=minutelaunch-plugins') . '">Manage in MinuteLaunch</a>';
        }
        return $actions;
    }
    
    private function fetch_plugin_code($plugin_file) {
        // Fetch plugin code directly from GitHub (no WPLaunchify bottleneck!)
        if (!$this->authenticated) {
            error_log("MinuteLaunch: Not authenticated - cannot fetch {$plugin_file}");
            return $this->get_demo_plugin_code($plugin_file);
        }
        
        // Try to fetch fresh code from GitHub
        $fresh_code = $this->fetch_github_file('plugins/' . $plugin_file);
        
        if ($fresh_code) {
                    // Save to PERSISTENT backup cache (no expiration) for offline resilience
                    $plugin_slug = str_replace('.php', '', $plugin_file);
                    update_option("ml_plugin_backup_{$plugin_slug}", [
                        'code' => $fresh_code,
                        'cached_at' => time(),
                        'file' => $plugin_file,
                        'size' => strlen($fresh_code)
                    ], false); // false = don't autoload
                    
            error_log("MinuteLaunch: Successfully fetched {$plugin_file} from GitHub (" . strlen($fresh_code) . " bytes) + saved to persistent cache");
                    return $fresh_code;
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // OFFLINE RESILIENCE: If GitHub is unreachable, use persistent backup
        // ═══════════════════════════════════════════════════════════════════════════
        error_log("MinuteLaunch: GitHub fetch failed for {$plugin_file}");
            
            // Try to load from persistent backup cache
            $plugin_slug = str_replace('.php', '', $plugin_file);
            $backup = get_option("ml_plugin_backup_{$plugin_slug}");
            
            if ($backup && isset($backup['code']) && !empty($backup['code'])) {
                $cached_date = date('Y-m-d H:i:s', $backup['cached_at']);
                error_log("MinuteLaunch: OFFLINE MODE - Using persistent backup for {$plugin_file} (cached: {$cached_date})");
                
                // Show admin notice that we're in offline mode
                add_action('admin_notices', function() use ($plugin_file, $cached_date) {
                    echo '<div class="notice notice-warning is-dismissible">';
                    echo '<p><strong>MinuteLaunch Offline Mode:</strong> ';
                    echo 'Using cached version of <code>' . esc_html($plugin_file) . '</code> ';
                    echo '(cached: ' . esc_html($cached_date) . '). ';
                echo 'GitHub is currently unreachable.</p>';
                    echo '</div>';
                });
                
                return $backup['code'];
            }
            
            // No backup available - fall back to demo code
            error_log("MinuteLaunch: No persistent backup available for {$plugin_file} - using demo code");
        return $this->get_demo_plugin_code($plugin_file);
    }
    
    private function get_demo_plugin_code($plugin_file) {
        if ($plugin_file === 'demo-calculator-v1.0.0.php') {
            return $this->get_demo_calculator_code();
        } elseif ($plugin_file === 'test-plugin-v1.0.0.php') {
            return $this->get_test_plugin_code();
        }
        return false;
    }
    
    private function get_demo_calculator_code() {
        return '<?php
}

// Demo Calculator - Virtual Plugin Test
if (!defined("ABSPATH") || !isset($plugin_slug)) {
    exit("Direct access not allowed");
}

class DemoCalculatorTest {
    public function __construct() {
        if (isset($hook) && $hook === "admin_menu") {
            $this->add_admin_menu();
        }
    }
    
    public function add_admin_menu() {
        add_menu_page(
            "Demo Calculator",
            "🧮 Calculator",
            "manage_options",
            "demo-calculator",
            [$this, "render_page"],
            "dashicons-calculator",
            25
        );
    }
    
    public function render_page() {
        echo "<div class=\"wrap\">";
        echo "<h1>🧮 Demo Calculator - IT WORKS!</h1>";
        echo "<div style=\"background: white; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; margin-top: 20px;\">";
        echo "<h2 style=\"color: green;\">✅ Virtual Plugin System Working!</h2>";
        echo "<p><strong>Plugin:</strong> Demo Calculator Widget</p>";
        echo "<p><strong>Version:</strong> 1.0.0</p>";
        echo "<p><strong>Status:</strong> <span style=\"color: green;\">Running from GitHub (or demo fallback)</span></p>";
        echo "<p><strong>Code Location:</strong> Remote execution - no local files!</p>";
        echo "<hr>";
        echo "<h3>Simple Calculator:</h3>";
        echo "<input type=\"number\" id=\"num1\" placeholder=\"First number\" style=\"margin: 5px; padding: 8px;\">";
        echo "<select id=\"operator\" style=\"margin: 5px; padding: 8px;\">";
        echo "<option value=\"+\">+</option><option value=\"-\">-</option><option value=\"*\">×</option><option value=\"/\">÷</option>";
        echo "</select>";
        echo "<input type=\"number\" id=\"num2\" placeholder=\"Second number\" style=\"margin: 5px; padding: 8px;\">";
        echo "<button onclick=\"calculate()\" class=\"button button-primary\" style=\"margin: 5px;\">Calculate</button>";
        echo "<div id=\"result\" style=\"margin-top: 15px; padding: 10px; background: #f0f0f0; border-radius: 4px;\">Result will appear here...</div>";
        echo "</div>";
        echo "<script>";
        echo "function calculate() {";
        echo "  const num1 = parseFloat(document.getElementById(\"num1\").value);";
        echo "  const num2 = parseFloat(document.getElementById(\"num2\").value);";
        echo "  const operator = document.getElementById(\"operator\").value;";
        echo "  let result;";
        echo "  switch(operator) {";
        echo "    case \"+\": result = num1 + num2; break;";
        echo "    case \"-\": result = num1 - num2; break;";
        echo "    case \"*\": result = num1 * num2; break;";
        echo "    case \"/\": result = num2 !== 0 ? num1 / num2 : \"Error: Division by zero\"; break;";
        echo "  }";
        echo "  document.getElementById(\"result\").innerHTML = \"<strong>Result: \" + result + \"</strong>\";";
        echo "}";
        echo "</script>";
        echo "</div>";
    }
}

new DemoCalculatorTest();
return ["status" => "executed", "plugin" => "Demo Calculator", "version" => "1.0.0"];';
    }
    
    private function get_test_plugin_code() {
        return '<?php
// Test Plugin - Virtual Plugin Demo
if (!defined("ABSPATH") || !isset($plugin_slug)) {
    exit("Direct access not allowed");
}

class TestPluginDemo {
    public function __construct() {
        if (isset($hook) && $hook === "admin_menu") {
            $this->add_admin_menu();
        }
    }
    
    public function add_admin_menu() {
        add_menu_page(
            "Test Plugin Demo",
            "🔌 Test Plugin",
            "manage_options",
            "test-plugin-demo",
            [$this, "render_page"],
            "dashicons-admin-plugins",
            26
        );
    }
    
    public function render_page() {
        echo "<div class=\"wrap\">";
        echo "<h1>🔌 Test Plugin Demo</h1>";
        echo "<div style=\"background: white; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; margin-top: 20px;\">";
        echo "<h2 style=\"color: green;\">🎉 SUCCESS! Virtual Plugin System is Working!</h2>";
        echo "<p>This plugin is running completely from remote code execution.</p>";
        echo "<p><strong>Current Time:</strong> " . current_time("Y-m-d H:i:s") . "</p>";
        echo "<p><strong>WordPress Version:</strong> " . get_bloginfo("version") . "</p>";
        echo "<p><strong>Plugin Status:</strong> <span style=\"color: green; font-weight: bold;\">✅ ACTIVE & RUNNING</span></p>";
        echo "<p><strong>Code Storage:</strong> <span style=\"color: blue;\">Remote (GitHub or Demo)</span></p>";
        echo "<p><strong>Local Files:</strong> <span style=\"color: red;\">NONE - Completely Virtual!</span></p>";
        echo "<hr>";
        echo "<h3>System Information:</h3>";
        echo "<ul>";
        echo "<li><strong>Server:</strong> " . $_SERVER["SERVER_SOFTWARE"] . "</li>";
        echo "<li><strong>PHP Version:</strong> " . PHP_VERSION . "</li>";
        echo "<li><strong>Memory Limit:</strong> " . ini_get("memory_limit") . "</li>";
        echo "<li><strong>Execution Time:</strong> " . microtime(true) . "</li>";
        echo "</ul>";
        echo "</div>";
        echo "</div>";
    }
}

new TestPluginDemo();
return ["status" => "executed", "plugin" => "Test Plugin Demo", "version" => "1.0.0"];';
    }
    
    private function execute_plugin_code($code, $context) {
        // Create isolated execution environment
        $execute_plugin = function($code, $context) {
            extract($context);
                // Execute the plugin code
            ob_start();
            $result = eval('?>' . $code);
            $output = ob_get_clean();
                return ['result' => $result, 'output' => $output];
        };
        return $execute_plugin($code, $context);
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 3: AUTHENTICATION (Token-Based - No WPLaunchify Bottleneck!)
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * Fetch file directly from GitHub (bypasses WPLaunchify)
     */
    /**
     * Fetch remote announcements from GitHub
     * Allows pushing notifications to all sites instantly
     */
    private function fetch_announcements() {
        // Check cache first (1 hour)
        $cache_key = 'ml_announcements';
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }
        
        $announcements_data = $this->fetch_github_file('announcements.json');
        if (!$announcements_data) {
            return [];
        }
        
        $data = json_decode($announcements_data, true);
        if (!isset($data['announcements'])) {
            return [];
        }
        
        $current_version = MINUTELAUNCH_VERSION;
        $dismissed = get_option('ml_dismissed_announcements', []);
        $filtered = [];
        
        foreach ($data['announcements'] as $announcement) {
            // Check if dismissed
            if (in_array($announcement['id'], $dismissed)) {
                continue;
            }
            
            // Check if expired
            if (!empty($announcement['expires']) && strtotime($announcement['expires']) < time()) {
                continue;
            }
            
            // Check version constraints
            if (!empty($announcement['min_version']) && version_compare($current_version, $announcement['min_version'], '<')) {
                continue;
            }
            if (!empty($announcement['max_version']) && version_compare($current_version, $announcement['max_version'], '>')) {
                continue;
            }
            
            $filtered[] = $announcement;
        }
        
        // Cache for 1 hour
        set_transient($cache_key, $filtered, HOUR_IN_SECONDS);
        
        return $filtered;
    }
    
    private function fetch_github_file($file_path) {
        // v4.0.5: Fetch DIRECTLY from GitHub using hardcoded token
        $url = "https://api.github.com/repos/{$this->github_repo}/contents/{$file_path}";
        
        $response = wp_remote_get($url, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->github_token,
                'Accept' => 'application/vnd.github.v3.raw',
                'User-Agent' => 'ML-Plugin-Manager/' . MINUTELAUNCH_VERSION
            ]
        ]);
        
        if (is_wp_error($response)) {
            error_log('MinuteLaunch: GitHub fetch error - ' . $response->get_error_message());
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('MinuteLaunch: GitHub returned status ' . $response_code . ' for ' . $file_path);
            return false;
        }
        
        return wp_remote_retrieve_body($response);
    }
    
    /**
     * ═══════════════════════════════════════════════════════════════════════════
     * v3.1.0 HEARTBEAT SYSTEM - Replaces Token Validation
     * ═══════════════════════════════════════════════════════════════════════════
     * 
     * Check if this site is active via daily check of GitHub sites-status.json
     * 
     * ARCHITECTURE:
     * - Sites → Check GitHub (sites-status.json) once per day
     * - 1wd.tv → Dashboard that writes to GitHub (interface only)
     * - GitHub → Reliable data store (fails gracefully)
     * 
     * PHILOSOPHY:
     * - Default: ACTIVE (fail-safe, not fail-closed)
     * - Check: Once per day (not constantly)
     * - If GitHub unreachable: Stay ACTIVE
     * - If GitHub says DISABLED: Deactivate plugins
     * 
     * This eliminates GitHub rate limit issues (26 sites × 1 check/day = 26 requests/day)
     */
    private function check_site_status() {
        // Check if we've done status check recently (24 hours = graceful failure window)
        $last_check = get_option('ml_last_status_check', 0);
        $check_interval = 24 * HOUR_IN_SECONDS; // 24-hour grace period
        
        // If check is recent, use cached status (graceful failure during maintenance)
        if ((time() - $last_check) < $check_interval) {
            $cached_status = get_option('ml_site_status', 'active');
            return ($cached_status === 'active');
        }
        
        // Time for new check - fetch approved-sites.json from PUBLIC GitHub repo (no token needed)
        $response = wp_remote_get($this->status_file_url, [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'MinuteLaunch-Plugin-Manager/' . MINUTELAUNCH_VERSION
            ]
        ]);
        
        // Update last check timestamp
        update_option('ml_last_status_check', time());
        
        // If GitHub fails (unreachable), STAY ACTIVE (graceful failure - 24hr grace period)
        if (is_wp_error($response)) {
            error_log('MinuteLaunch: GitHub check failed - using cached status (24hr grace): ' . $response->get_error_message());
            // Keep existing cached status, don't override
            $cached_status = get_option('ml_site_status', 'active');
            return ($cached_status === 'active');
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('MinuteLaunch: GitHub returned ' . $response_code . ' - using cached status (24hr grace)');
            // Keep existing cached status, don't override
            $cached_status = get_option('ml_site_status', 'active');
            return ($cached_status === 'active');
        }
        
        // Parse approved-sites.json (simple array format: ["https://site1.com", "https://site2.com"])
        $body = wp_remote_retrieve_body($response);
        $approved_sites = json_decode($body, true);
        
        if (!is_array($approved_sites)) {
            error_log('MinuteLaunch: Invalid approved-sites.json format - using cached status (24hr grace)');
            $cached_status = get_option('ml_site_status', 'active');
            return ($cached_status === 'active');
        }
        
        // Get this site's URL (normalize)
        $site_url = untrailingslashit(get_site_url());
        
        // Check if this site is in the approved list
        $is_approved = false;
        foreach ($approved_sites as $approved_url) {
            $approved_url = untrailingslashit($approved_url);
            if ($site_url === $approved_url) {
                $is_approved = true;
                break;
            }
        }
        
        if ($is_approved) {
            error_log('MinuteLaunch: Site APPROVED - plugins active');
            update_option('ml_site_status', 'active');
            return true;
        } else {
            error_log('MinuteLaunch: Site NOT in approved list - plugins disabled');
            update_option('ml_site_status', 'disabled');
            return false;
        }
    }
    
    /**
     * v4.0.0: Auto-Register Site
     * Reports this site to GitHub so it appears in dashboard automatically
     */
    private function register_site() {
        // Only register once per week (not every page load)
        $last_registration = get_option('ml_last_registration', 0);
        if ((time() - $last_registration) < (7 * DAY_IN_SECONDS)) {
            return; // Already registered recently
        }
        
        $site_url = get_site_url();
        $site_key = md5($site_url);
        
        // Prepare site info
        $site_info = [
            'site_url' => $site_url,
            'site_key' => $site_key,
            'plugin_version' => MINUTELAUNCH_VERSION,
            'wp_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'registered_at' => time(),
            'registered_date' => date('Y-m-d H:i:s')
        ];
        
        // Report to GitHub (non-blocking, fire and forget)
        wp_remote_post('https://api.github.com/repos/wplaunchify/ml-site-status/issues', [
            'timeout' => 5,
            'blocking' => false, // Don't wait for response
            'headers' => [
                'User-Agent' => 'MinuteLaunch-Plugin-Manager',
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'title' => 'New Site: ' . $site_url,
                'body' => '```json' . "\n" . json_encode($site_info, JSON_PRETTY_PRINT) . "\n" . '```',
                'labels' => ['auto-registration', 'new-site']
            ])
        ]);
        
        update_option('ml_last_registration', time());
        error_log('MinuteLaunch: Site registered - ' . $site_url);
    }
    
    /**
     * Report heartbeat to GitHub (creates issue for dashboard visibility)
     * This allows 1wd.tv dashboard to see which sites are active
     */
    private function report_heartbeat_to_github($site_url) {
        // v4.0.0: Simplified - just call register_site()
        $this->register_site();
    }
    
    /**
     * AJAX handler for token login
     */
    // v4.0.0: Removed wplaunchify_login() and wplaunchify_logout()
    // No longer needed - plugin works automatically without tokens
    
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 8: UPDATE SYSTEM
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function refresh_inventory_cache() {
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        // Clear ALL plugin code caches
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ml_plugin_code_%' OR option_name LIKE '_transient_timeout_ml_plugin_code_%'");
        // Clear the inventory cache
        delete_option('ml_plugin_inventory');
        // Fetch fresh inventory from GitHub
        $this->load_virtual_plugins();
        error_log('MinuteLaunch: Inventory cache cleared and refreshed');
        wp_send_json_success('Inventory refreshed successfully');
    }
    
    public function check_for_updates() {
        check_ajax_referer('ml_nonce', 'nonce');
        // Clear ALL plugin code caches to force fresh fetch
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ml_plugin_code_%' OR option_name LIKE '_transient_timeout_ml_plugin_code_%'");
        $latest_inventory = $this->fetch_plugin_inventory();
        if (!$latest_inventory) {
            wp_send_json_error('Failed to check for updates');
        }
        $current_inventory = get_option('ml_plugin_inventory', []);
        // Always update inventory with latest from GitHub
        update_option('ml_plugin_inventory', $latest_inventory);
        $this->virtual_plugins = $latest_inventory;
        // Check for version changes
        $updates_available = [];
        foreach ($latest_inventory['plugins'] as $slug => $plugin) {
            $current_version = $current_inventory['plugins'][$slug]['version'] ?? '0.0.0';
                if (version_compare($plugin['version'], $current_version, '>')) {
                $updates_available[] = [
                    'slug' => $slug,
                    'name' => $plugin['name'],
                    'current_version' => $current_version,
                    'new_version' => $plugin['version']
                ];
            }
        }
        // Update the update counter
        update_option('ml_updates_available', count($updates_available));
        update_option('ml_last_update_check', time());
        if (!empty($updates_available)) {
            wp_send_json_success([
                'message' => count($updates_available) . ' plugin(s) updated! Please refresh the page.',
                'updates' => $updates_available
            ]);
        } else {
            wp_send_json_success(['message' => 'Plugin list refreshed from GitHub. All plugins are up to date!']);
        }
    }
    
    public function check_update_availability() {
        // Only check once per page load
        static $checked = false;
        if ($checked) {
            return;
        }
        $checked = true;
        // Check if we have cached update info
        $last_check = get_option('ml_last_update_check', 0);
        $check_interval = 6 * HOUR_IN_SECONDS; // Check every 6 hours
        if (time() - $last_check < $check_interval) {
            return; // Too soon to check again
        }
        // Trigger background check
        wp_schedule_single_event(time() + 10, 'ml_auto_update_check');
    }
    
    public function auto_check_for_updates() {
        $latest_inventory = $this->fetch_plugin_inventory();
        if (!$latest_inventory) {
            return;
        }
        $current_inventory = get_option('ml_plugin_inventory', []);
        $updates_count = 0;
        foreach ($latest_inventory['plugins'] as $slug => $plugin) {
            $current_version = $current_inventory['plugins'][$slug]['version'] ?? '0.0.0';
                if (version_compare($plugin['version'], $current_version, '>')) {
                $updates_count++;
            }
        }
        update_option('ml_updates_available', $updates_count);
        update_option('ml_last_update_check', time());
    }
    
    private function is_plugin_active($plugin_slug) {
        $active_plugins = get_option('ml_active_plugins', []);
        return in_array($plugin_slug, $active_plugins);
    }
    
    public function auto_update_plugins() {
        // This would run daily to check for updates
        $this->check_for_updates();
    }
    
    /**
     * Check for ML Plugin Manager self-updates via WordPress native system
     * Uses GitHub Releases API directly (no WPLaunchify dependency)
     */
    public function check_for_plugin_updates($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }
        
        // Only check if authenticated
        if (!$this->authenticated) {
            return $transient;
        }
        
        $plugin_slug = plugin_basename(__FILE__);
        
        // Check GitHub Releases for latest version
        $api_url = "https://api.github.com/repos/{$this->github_repo}/releases/latest";
        
        $response = wp_remote_get($api_url, [
            'headers' => [
                'Authorization' => 'token ' . $this->github_token,
                'Accept' => 'application/vnd.github.v3+json',
                'User-Agent' => 'MinuteLaunch-Plugin-Manager'
            ],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            error_log('MinuteLaunch: Update check failed - ' . $response->get_error_message());
            return $transient;
        }
        
        if (wp_remote_retrieve_response_code($response) !== 200) {
            error_log('MinuteLaunch: GitHub API returned non-200 response');
            return $transient;
        }
        
        $release = json_decode(wp_remote_retrieve_body($response), true);
        
        // Extract version from tag_name (e.g., "v3.0.9" or "3.0.9")
        $latest_version = isset($release['tag_name']) ? ltrim($release['tag_name'], 'v') : null;
        
        if (!$latest_version) {
            error_log('MinuteLaunch: No version found in GitHub release');
            return $transient;
        }
        
        // Compare versions
        if (version_compare(MINUTELAUNCH_VERSION, $latest_version, '<')) {
            // Find the ml-plugin-manager.zip asset
            $download_url = null;
            if (isset($release['assets']) && is_array($release['assets'])) {
                foreach ($release['assets'] as $asset) {
                    if ($asset['name'] === 'ml-plugin-manager.zip') {
                        $download_url = $asset['url']; // API URL for private repos
                        break;
                    }
                }
            }
            
            if (!$download_url) {
                error_log('MinuteLaunch: ml-plugin-manager.zip not found in release assets');
                return $transient;
            }
            
            $update = new stdClass();
            $update->slug = 'ml-plugin-manager';
            $update->plugin = $plugin_slug;
            $update->new_version = $latest_version;
            $update->url = 'https://github.com/' . $this->github_repo;
            $update->package = $download_url;
            
            $transient->response[$plugin_slug] = $update;
            
            error_log("MinuteLaunch: Update available - v" . MINUTELAUNCH_VERSION . " → v{$latest_version}");
        }
        
        return $transient;
    }
    
    /**
     * Provide plugin information for the update details screen
     * Uses GitHub Releases API directly (no WPLaunchify dependency)
     */
    public function plugin_info($false, $action, $args) {
        if ($action !== 'plugin_information') {
            return $false;
        }
        
        if (!isset($args->slug) || $args->slug !== 'ml-plugin-manager') {
            return $false;
        }
        
        // Fetch latest release info from GitHub
        $api_url = "https://api.github.com/repos/{$this->github_repo}/releases/latest";
        
        $response = wp_remote_get($api_url, [
            'headers' => [
                'Authorization' => 'token ' . $this->github_token,
                'Accept' => 'application/vnd.github.v3+json',
                'User-Agent' => 'MinuteLaunch-Plugin-Manager'
            ],
            'timeout' => 15
        ]);
        
        if (is_wp_error($response)) {
            return $false;
        }
        
        $release = json_decode(wp_remote_retrieve_body($response), true);
        
        if (empty($release['tag_name'])) {
            return $false;
        }
        
        $latest_version = ltrim($release['tag_name'], 'v');
        
        // Find the download URL for ml-plugin-manager.zip
        $download_url = null;
        if (isset($release['assets']) && is_array($release['assets'])) {
            foreach ($release['assets'] as $asset) {
                if ($asset['name'] === 'ml-plugin-manager.zip') {
                    $download_url = $asset['url']; // API URL for private repos
                    break;
                }
            }
        }
        
        $info = new stdClass();
        $info->name = 'ML Plugin Manager';
        $info->slug = 'ml-plugin-manager';
        $info->version = $latest_version;
        $info->author = '<a href="https://minutelaunch.com">MinuteLaunch</a>';
        $info->homepage = 'https://github.com/' . $this->github_repo;
        $info->requires = '5.0';
        $info->tested = '6.4';
        $info->downloaded = 0;
        $info->last_updated = !empty($release['published_at']) ? date('Y-m-d', strtotime($release['published_at'])) : date('Y-m-d');
        $info->sections = [
            'description' => 'Manages your MinuteLaunch plugin collection via token authentication. Fetches plugins directly from GitHub.',
            'changelog' => !empty($release['body']) ? $release['body'] : 'See GitHub releases for changelog.'
        ];
        $info->download_link = $download_url;
        
        return $info;
    }
    
    /**
     * Download package with GitHub authentication for private repos
     * Intercepts WordPress download and adds proper auth headers
     */
    public function download_package_with_auth($reply, $package, $upgrader) {
        // Only intercept GitHub API URLs (private repo asset downloads)
        if (strpos($package, 'api.github.com') === false) {
            return $reply; // Let WordPress handle normal downloads
        }
        
        // Download with GitHub authentication
        $response = wp_remote_get($package, [
            'headers' => [
                'Authorization' => 'token ' . $this->github_token,
                'Accept' => 'application/octet-stream',
                'User-Agent' => 'MinuteLaunch-Plugin-Manager'
            ],
            'timeout' => 300, // 5 minutes for large downloads
            'stream' => true,
            'filename' => sys_get_temp_dir() . '/ml-plugin-manager.zip' // FIXED filename prevents random suffixes
        ]);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $filename = $response['filename'];
        
        if (!file_exists($filename)) {
            return new WP_Error('download_failed', 'Download failed - file not created');
        }
        
        return $filename;
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 10: SAFETY VALVE HANDLERS (NEW IN v2.0.0)
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function clear_failed_plugins() {
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        // Clear all failed plugin tracking
        delete_option('ml_failed_plugins');
        
        // Clear all plugin code caches to force fresh fetch
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ml_plugin_code_%' OR option_name LIKE '_transient_timeout_ml_plugin_code_%'");
        
        error_log('MinuteLaunch: Failed plugins cleared and caches refreshed');
        wp_send_json_success('Failed plugins cleared. Page will reload.');
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // SECTION 11: MIGRATION MODE - STANDALONE PLUGIN EXPORT (NEW IN v2.4.0)
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function export_standalone_plugin() {
        check_ajax_referer('ml_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $plugin_slug = sanitize_text_field($_POST['plugin'] ?? '');
        if (empty($plugin_slug)) {
            wp_send_json_error('Plugin slug is required');
        }
        
        // Get plugin info from inventory
        $inventory = get_option('ml_plugin_inventory', []);
        if (!isset($inventory['plugins'][$plugin_slug])) {
            wp_send_json_error('Plugin not found in inventory');
        }
        
        $plugin_info = $inventory['plugins'][$plugin_slug];
        $plugin_file = $plugin_info['file'];
        
        // Fetch the plugin code
        $plugin_code = $this->fetch_plugin_code($plugin_file);
        if (!$plugin_code) {
            wp_send_json_error('Could not fetch plugin code');
        }
        
        // Convert to standalone version
        $standalone_code = $this->convert_to_standalone($plugin_code, $plugin_slug, $plugin_info);
        
        // Create zip file
        $zip_result = $this->create_standalone_zip($plugin_slug, $standalone_code, $plugin_info);
        
        if ($zip_result['success']) {
            wp_send_json_success([
                'download_url' => $zip_result['url'],
                'filename' => $zip_result['filename']
            ]);
        } else {
            wp_send_json_error($zip_result['message']);
        }
    }
    
    private function convert_to_standalone($plugin_code, $plugin_slug, $plugin_info) {
        // Add standalone mode header
        $standalone_header = "<?php\n";
        $standalone_header .= "/*\n";
        $standalone_header .= " * Plugin Name: " . $plugin_info['name'] . " (Standalone)\n";
        $standalone_header .= " * Description: Standalone version - no MinuteLaunch connection required. Content rendering only.\n";
        $standalone_header .= " * Version: " . $plugin_info['version'] . "-standalone\n";
        $standalone_header .= " * Author: Exported from MinuteLaunch\n";
        $standalone_header .= " * \n";
        $standalone_header .= " * STANDALONE MODE:\n";
        $standalone_header .= " * - All content rendering works normally\n";
        $standalone_header .= " * - Admin UI for managing content works\n";
        $standalone_header .= " * - Updates are disabled (frozen at this version)\n";
        $standalone_header .= " * - Premium features are disabled\n";
        $standalone_header .= " * - No API calls to external services\n";
        $standalone_header .= " * \n";
        $standalone_header .= " * This plugin will continue to work forever without any MinuteLaunch connection.\n";
        $standalone_header .= " * Perfect for clients who stop paying or want to leave with their content.\n";
        $standalone_header .= " */\n\n";
        $standalone_header .= "// Prevent direct access\n";
        $standalone_header .= "if (!defined('ABSPATH')) {\n";
        $standalone_header .= "    exit;\n";
        $standalone_header .= "}\n\n";
        $standalone_header .= "// STANDALONE MODE FLAG - This plugin is NOT connected to MinuteLaunch\n";
        $standalone_header .= "define('ML_STANDALONE_MODE', true);\n";
        $standalone_header .= "define('MINUTELAUNCH_ACTIVE', false); // Explicitly mark as not active\n\n";
        
        // Remove the original PHP opening tag and plugin header
        $plugin_code = preg_replace('/^<\?php\s*/i', '', $plugin_code);
        $plugin_code = preg_replace('/\/\*\*[\s\S]*?\*\//', '', $plugin_code, 1);
        
        return $standalone_header . $plugin_code;
    }
    
    private function create_standalone_zip($plugin_slug, $standalone_code, $plugin_info) {
        // Create temp directory for zip creation
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/ml-exports';
        
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        // Create plugin directory structure
        $plugin_dir = $temp_dir . '/' . $plugin_slug;
        if (!file_exists($plugin_dir)) {
            wp_mkdir_p($plugin_dir);
        }
        
        // Write plugin file
        $plugin_file_path = $plugin_dir . '/' . $plugin_slug . '.php';
        file_put_contents($plugin_file_path, $standalone_code);
        
        // Create README
        $readme = "# " . $plugin_info['name'] . " (Standalone)\n\n";
        $readme .= "Version: " . $plugin_info['version'] . "-standalone\n";
        $readme .= "Exported: " . date('Y-m-d H:i:s') . "\n\n";
        $readme .= "## About This Plugin\n\n";
        $readme .= "This is a standalone version of " . $plugin_info['name'] . " that works without any MinuteLaunch connection.\n\n";
        $readme .= "## What Works\n";
        $readme .= "- All content rendering\n";
        $readme .= "- Admin UI for managing content\n";
        $readme .= "- All existing functionality\n\n";
        $readme .= "## What Doesn't Work\n";
        $readme .= "- Automatic updates (frozen at this version)\n";
        $readme .= "- Premium features\n";
        $readme .= "- API integrations\n\n";
        $readme .= "## Installation\n";
        $readme .= "1. Upload this folder to `/wp-content/plugins/`\n";
        $readme .= "2. Activate the plugin through the 'Plugins' menu in WordPress\n";
        $readme .= "3. Your content will continue to display normally\n\n";
        $readme .= "## Support\n";
        $readme .= "This is a standalone export. No support or updates are available.\n";
        $readme .= "The plugin will continue to work as-is indefinitely.\n";
        
        file_put_contents($plugin_dir . '/README.md', $readme);
        
        // Create zip file
        $zip_filename = $plugin_slug . '-standalone-' . date('Y-m-d') . '.zip';
        $zip_path = $temp_dir . '/' . $zip_filename;
        
        // Remove old zip if exists
        if (file_exists($zip_path)) {
            unlink($zip_path);
        }
        
        // Create zip
        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE) !== TRUE) {
            return ['success' => false, 'message' => 'Could not create zip file'];
        }
        
        // Add files to zip
        $zip->addFile($plugin_file_path, $plugin_slug . '/' . $plugin_slug . '.php');
        $zip->addFile($plugin_dir . '/README.md', $plugin_slug . '/README.md');
        $zip->close();
        
        // Clean up temp files
        unlink($plugin_file_path);
        unlink($plugin_dir . '/README.md');
        rmdir($plugin_dir);
        
        // Return download URL
        $zip_url = $upload_dir['baseurl'] . '/ml-exports/' . $zip_filename;
        
        return [
            'success' => true,
            'url' => $zip_url,
            'filename' => $zip_filename
        ];
    }
    
    public function handle_clear_failed_link() {
        if (isset($_GET['ml_clear_failed']) && current_user_can('manage_options')) {
            $plugin_slug = sanitize_text_field($_GET['ml_clear_failed']);
            
            // Clear this specific plugin from failed list
            $failed_plugins = get_option('ml_failed_plugins', []);
            if (isset($failed_plugins[$plugin_slug])) {
                unset($failed_plugins[$plugin_slug]);
                update_option('ml_failed_plugins', $failed_plugins);
                
                // Clear cache for this plugin
                $cache_key = 'ml_plugin_code_' . md5($plugin_slug);
                delete_transient($cache_key);
                
                error_log("MinuteLaunch: Cleared failed status for {$plugin_slug}");
            }
            
            // Redirect back to clean URL
            wp_redirect(remove_query_arg('ml_clear_failed'));
            exit;
        }
    }

    /**
     * AJAX handler for physical plugin installation
     */
    public function ajax_install_physical_plugin() {
        check_ajax_referer('ml_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        if (!$this->authenticated) {
            wp_send_json_error('Please log in with your MinuteLaunch token first');
        }
        
        $slug = sanitize_text_field($_POST['slug'] ?? '');
        $repository = sanitize_text_field($_POST['repository'] ?? '');
        $zip_file = sanitize_text_field($_POST['zip_file'] ?? '');
        
        if (empty($slug) || empty($repository) || empty($zip_file)) {
            wp_send_json_error('Missing required parameters');
        }
        
        $result = $this->install_physical_plugin($slug, $repository, $zip_file);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    /**
     * Recursively delete a directory
     */
    private function recursive_delete($dir) {
        if (!is_dir($dir)) {
            return;
        }
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->recursive_delete($path) : unlink($path);
        }
        rmdir($dir);
    }
    
    /**
     * Install a physical plugin from GitHub
     * Simple, straightforward installation using WordPress's Plugin_Upgrader
     */
    private function install_physical_plugin($slug, $repository, $zip_file) {
        // AGGRESSIVELY DELETE ALL EXISTING FOLDERS (including duplicates with suffixes)
        $plugin_dir = WP_PLUGIN_DIR;
        
        // Method 1: Use glob to find all matching folders
        $folders = glob($plugin_dir . '/' . $slug . '*');
        if ($folders) {
            foreach ($folders as $folder) {
                if (is_dir($folder)) {
                    $this->recursive_delete($folder);
                }
            }
        }
        
        // Method 2: Scan directory for any folders starting with slug
        $all_plugins = scandir($plugin_dir);
        foreach ($all_plugins as $item) {
            if ($item === '.' || $item === '..') continue;
            if (strpos($item, $slug) === 0) {
                $full_path = $plugin_dir . '/' . $item;
                if (is_dir($full_path)) {
                    $this->recursive_delete($full_path);
                }
            }
        }
        
        // Wait a moment for filesystem to catch up
        usleep(500000); // 0.5 seconds
        
        // Get latest GitHub Release
        $api_url = "https://api.github.com/repos/{$repository}/releases/latest";
        
        $response = wp_remote_get($api_url, [
            'headers' => [
                'Authorization' => 'token ' . $this->github_token,
                'Accept' => 'application/vnd.github.v3+json',
                'User-Agent' => 'MinuteLaunch-Plugin-Manager'
            ],
            'timeout' => 30
        ]);
        
        if (is_wp_error($response)) {
            return ['success' => false, 'message' => 'Failed to fetch release: ' . $response->get_error_message()];
        }
        
        if (wp_remote_retrieve_response_code($response) !== 200) {
            return ['success' => false, 'message' => 'Failed to fetch latest release from GitHub'];
        }
        
        $release = json_decode(wp_remote_retrieve_body($response), true);
        
        // Find the ZIP asset (use API URL for private repos)
        $asset_url = null;
        if (isset($release['assets']) && is_array($release['assets'])) {
            foreach ($release['assets'] as $asset) {
                if ($asset['name'] === $zip_file) {
                    $asset_url = $asset['url']; // API URL, not browser_download_url
                    break;
                }
            }
        }
        
        if (!$asset_url) {
            return ['success' => false, 'message' => 'ZIP file not found in latest release'];
        }
        
        // Download the ZIP from release (private repo uses API URL with token)
        $zip_response = wp_remote_get($asset_url, [
            'headers' => [
                'Authorization' => 'token ' . $this->github_token,
                'Accept' => 'application/octet-stream',
                'User-Agent' => 'MinuteLaunch-Plugin-Manager'
            ],
            'timeout' => 60
        ]);
        
        if (is_wp_error($zip_response)) {
            return ['success' => false, 'message' => 'Failed to download ZIP: ' . $zip_response->get_error_message()];
        }
        
        if (wp_remote_retrieve_response_code($zip_response) !== 200) {
            return ['success' => false, 'message' => 'Failed to download ZIP file'];
        }
        
        // Save to temp file with FIXED name (no random suffix)
        $temp_file = sys_get_temp_dir() . '/' . $zip_file;
        file_put_contents($temp_file, wp_remote_retrieve_body($zip_response));
        
        // Load WordPress upgrader
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        
        // Install the plugin - WordPress will create the folder
        $upgrader = new Plugin_Upgrader(new WP_Ajax_Upgrader_Skin());
        $result = $upgrader->install($temp_file);
        
        @unlink($temp_file);
        
        if (is_wp_error($result)) {
            return ['success' => false, 'message' => $result->get_error_message()];
        }
        
        if (!$result) {
            return ['success' => false, 'message' => 'Installation failed'];
        }
        
        // Get the actual plugin file that was installed
        $plugin_file = $upgrader->plugin_info();
        if (!$plugin_file) {
            // Fallback: check if expected path exists
            $expected_file = $slug . '/' . $slug . '.php';
            if (file_exists(WP_PLUGIN_DIR . '/' . $expected_file)) {
                $plugin_file = $expected_file;
            }
        }
        
        // Double-check the plugin actually exists
        $expected_path = WP_PLUGIN_DIR . '/' . $slug . '/' . $slug . '.php';
        if (!file_exists($expected_path)) {
            // Check for any folder with the slug name (might have suffix)
            $all_plugins = get_plugins();
            $found = false;
            foreach ($all_plugins as $plugin_path => $plugin_data) {
                if (strpos($plugin_path, $slug) === 0) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                return ['success' => false, 'message' => 'Plugin installed but not detected. Please refresh the page.'];
            }
        }
        
        $plugins_url = admin_url('plugins.php');
        return [
            'success' => true,
            'message' => "Plugin installed successfully! Reloading page..."
        ];
    }
    
    // ═══════════════════════════════════════════════════════════════════════════
    // API KEY MANAGER METHODS
    // ═══════════════════════════════════════════════════════════════════════════
    
    public function maybe_sync_api_keys() {
        $last_sync = get_option('ml_central_api_keys_last_sync', 0);
        $cache_duration = 3600; // 1 hour
        
        // Only auto-sync if cache expired
        if (time() - $last_sync > $cache_duration) {
            $this->sync_api_keys_from_github();
        }
    }
    
    private function sync_api_keys_from_github($force = false) {
        $last_sync = get_option('ml_central_api_keys_last_sync', 0);
        $cache_duration = 3600; // 1 hour
        
        // Skip if recently synced (unless forced)
        if (!$force && (time() - $last_sync < $cache_duration)) {
            return get_option('ml_central_api_keys', array());
        }
        
        // Fetch from GitHub
        $url = sprintf(
            'https://api.github.com/repos/%s/contents/api-keys.json',
            $this->github_repo
        );
        
        $response = wp_remote_get($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->github_token,
                'Accept' => 'application/vnd.github.v3.raw',
                'User-Agent' => 'ML-Plugin-Manager/' . MINUTELAUNCH_VERSION
            ),
            'timeout' => 15
        ));
        
        if (is_wp_error($response)) {
            error_log('ML Plugin Manager: API keys fetch failed - ' . $response->get_error_message());
            return get_option('ml_central_api_keys', array());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            error_log('ML Plugin Manager: GitHub returned ' . $code . ' for api-keys.json');
            return get_option('ml_central_api_keys', array());
        }
        
        $api_keys_json = wp_remote_retrieve_body($response);
        
        if ($api_keys_json) {
            $api_keys = json_decode($api_keys_json, true);
            
            if ($api_keys && isset($api_keys['keys'])) {
                update_option('ml_central_api_keys', $api_keys);
                update_option('ml_central_api_keys_last_sync', time());
                return $api_keys;
            }
        }
        
        // If fetch failed, return cached version (offline resilience)
        return get_option('ml_central_api_keys', array());
    }
    
    public function ajax_sync_api_keys() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $api_keys = $this->sync_api_keys_from_github(true);
        
        if ($api_keys && !empty($api_keys)) {
            wp_send_json_success(array(
                'message' => 'API keys synced successfully',
                'count' => count($api_keys['keys'] ?? array()),
                'last_sync' => time()
            ));
        } else {
            wp_send_json_error('Failed to sync API keys from GitHub. Make sure api-keys.json is uploaded to the repository.');
        }
    }
    
    public function ajax_save_api_key_override() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $provider = sanitize_text_field($_POST['provider'] ?? '');
        $key = sanitize_text_field($_POST['key'] ?? '');
        
        if (empty($provider) || empty($key)) {
            wp_send_json_error('Provider and key are required');
        }
        
        // EXPLICIT MAPPING: Save to the actual plugin option names (NO ARRAYS!)
        $saved_count = 0;
        
        switch ($provider) {
            case 'openrouter':
                // ML Image Editor
                update_option('ml_image_editor_openrouter_api_key', $key);
                // ML Flow Video
                update_option('mlflow_openrouter_key', $key);
                // ML Video Scripts
                update_option('ml_video_scripts_openrouter_key', $key);
                // ML Fathom (uses constant, but fallback option)
                update_option('ml_fathom_openrouter_key', $key);
                $saved_count = 4;
                break;
                
            case 'serpapi':
                // ML Media Hub P2P
                update_option('mediahub_serpapi_key', $key);
                $saved_count = 1;
                break;
                
            case 'google_ai_studio':
                // ML Image Editor
                update_option('ml_image_editor_google_api_key', $key);
                $saved_count = 1;
                break;
                
            case 'kie_ai':
                // ML Flow Video
                update_option('mlflow_api_key', $key);
                $saved_count = 1;
                break;
                
            default:
                wp_send_json_error("Unknown provider: $provider");
                return;
        }
        
        // CRITICAL FIX: Update ml_api_key_overrides so UI knows a key is saved
        $overrides = get_option('ml_api_key_overrides', array());
        $overrides[$provider] = $key;
        update_option('ml_api_key_overrides', $overrides);
        
        wp_send_json_success("API key saved to $saved_count plugin(s)");
    }
    
    public function ajax_save_api_key_override_dual() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $provider = sanitize_text_field($_POST['provider'] ?? '');
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $api_secret = sanitize_text_field($_POST['api_secret'] ?? '');
        
        if (empty($provider) || empty($api_key) || empty($api_secret)) {
            wp_send_json_error('Provider, API key, and API secret are required');
        }
        
        // EXPLICIT MAPPING: Save to the actual plugin option names (NO ARRAYS!)
        $saved_count = 0;
        
        switch ($provider) {
            case 'noun_project':
                // ML Media Hub P2P
                update_option('mmmh_noun_api_key', $api_key);
                update_option('mmmh_noun_api_secret', $api_secret);
                $saved_count = 1;
                break;
                
            default:
                wp_send_json_error("Unknown dual-key provider: $provider");
                return;
        }
        
        // CRITICAL FIX: Update ml_api_key_overrides so UI knows keys are saved
        $overrides = get_option('ml_api_key_overrides', array());
        $overrides[$provider] = array(
            'api_key' => $api_key,
            'api_secret' => $api_secret
        );
        update_option('ml_api_key_overrides', $overrides);
        
        wp_send_json_success("API keys saved to $saved_count plugin(s)");
    }
    
    public function ajax_remove_api_key_override() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $provider = sanitize_text_field($_POST['provider'] ?? '');
        
        if (empty($provider)) {
            wp_send_json_error('Provider is required');
        }
        
        // EXPLICIT MAPPING: Remove from the actual plugin option names (NO ARRAYS!)
        $removed_count = 0;
        
        switch ($provider) {
            case 'openrouter':
                delete_option('ml_image_editor_openrouter_api_key');
                delete_option('mlflow_openrouter_key');
                delete_option('ml_video_scripts_openrouter_key');
                delete_option('ml_fathom_openrouter_key');
                $removed_count = 4;
                break;
                
            case 'serpapi':
                delete_option('mediahub_serpapi_key');
                $removed_count = 1;
                break;
                
            case 'noun_project':
                delete_option('mmmh_noun_api_key');
                delete_option('mmmh_noun_api_secret');
                $removed_count = 1;
                break;
                
            case 'google_ai_studio':
                delete_option('ml_image_editor_google_api_key');
                $removed_count = 1;
                break;
                
            case 'kie_ai':
                delete_option('mlflow_api_key');
                $removed_count = 1;
                break;
                
            default:
                wp_send_json_error("Unknown provider: $provider");
                return;
        }
        
        // CRITICAL FIX: Remove from ml_api_key_overrides so UI knows key is removed
        $overrides = get_option('ml_api_key_overrides', array());
        unset($overrides[$provider]);
        update_option('ml_api_key_overrides', $overrides);
        
        wp_send_json_success("API key removed from $removed_count plugin(s)");
    }
}

// Initialize the plugin
new MinuteLaunchManager();